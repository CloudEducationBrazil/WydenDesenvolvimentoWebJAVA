unit uCripto;

interface

uses
  SysUtils,
  Classes,
  EncdDecd;

function Criptografar(const Texto, Chave: string): string;
function Descriptografar(const Texto, Chave: string): string;
function GerarHash(const Texto: string): string;

implementation

function XORCrypt(const Texto, Chave: string): string;
var
  I, KeyLen: Integer;
begin
  Result := Texto;

  KeyLen := Length(Chave);

  for I := 1 to Length(Texto) do
  begin
    Result[I] := Char(
      Byte(Texto[I]) xor
      Byte(Chave[((I - 1) mod KeyLen) + 1])
    );
  end;
end;

function Criptografar(const Texto, Chave: string): string;
begin
  Result := EncodeString(
              XORCrypt(Texto, Chave)
            );
end;

function Descriptografar(const Texto, Chave: string): string;
begin
  Result := XORCrypt(
              DecodeString(Texto),
              Chave
            );
end;

function GerarHash(const Texto: string): string;
var
  I: Integer;
  Soma: LongInt;
begin
  Soma := 0;

  for I := 1 to Length(Texto) do
    Soma := Soma + Ord(Texto[I]) * I;

  Result := IntToHex(Soma, 8);
end;

end.
