unit uAppGeradorTokenSecurityConttrolCloud;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs;

type
  TfrmAppGeradorTokenSecurityConttrol = class(TForm)
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmAppGeradorTokenSecurityConttrol: TfrmAppGeradorTokenSecurityConttrol;

implementation

uses uSecurityConttrolCloud;

{$R *.dfm}

end.
