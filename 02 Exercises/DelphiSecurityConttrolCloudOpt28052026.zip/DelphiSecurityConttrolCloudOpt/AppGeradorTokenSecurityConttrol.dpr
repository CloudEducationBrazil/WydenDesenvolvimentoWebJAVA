program AppGeradorTokenSecurityConttrol;

uses
  Forms,
  Dialogs,
  uAppGeradorTokenSecurityConttrolCloud in 'uAppGeradorTokenSecurityConttrolCloud.pas' {frmAppGeradorTokenSecurityConttrol},
  uCripto in 'uCripto.pas',
  uSecurityConttrolCloud in 'uSecurityConttrolCloud.pas';

{$R *.res}

begin
  if not ValidarSistema then
  begin
    ShowMessage('Acesso n�o autorizado!');
    Halt;
  end;

  Application.Initialize;
  Application.CreateForm(TfrmAppGeradorTokenSecurityConttrol, frmAppGeradorTokenSecurityConttrol);
  Application.Run;
end.
