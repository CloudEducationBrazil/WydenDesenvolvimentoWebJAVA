object frmAppGeradorTokenSecurityConttrol: TfrmAppGeradorTokenSecurityConttrol
  Left = 1
  Top = 124
  Width = 928
  Height = 480
  Caption = 'App Gerador Token Security Conttrol'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
end
