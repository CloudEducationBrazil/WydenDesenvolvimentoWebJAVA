library PTcpClientDLL;

uses
  Windows, SysUtils, Classes, IdTCPClient, IdStack;

{$H-} // Importante: n�o usar long strings (compat�vel com Delphi 3)

// Aloca uma c�pia de um texto como PChar
function AllocPChar(const Texto: string): PChar;
begin
  Result := StrAlloc(Length(Texto) + 1);
  StrPCopy(Result, Texto);
end;

// Fun��o principal: Envia comando TCP e retorna resposta como PChar
procedure EnviarComandoTCP(
  Host: PChar;
  Port: Integer;
  const Comando: PChar;
  var Resposta: PChar;
  var Erro: PChar
); stdcall;
var
  Cliente: TIdTCPClient;
  Linha: string;
  Resultado: string;
begin
  Resposta := nil;
  Erro  := nil;

  Cliente := TIdTCPClient.Create(nil);
  try
    Cliente.Host := string(Host);//'192.168.0.48'; '127.0.0.1';
    Cliente.Port := Port; // 8587;
    Cliente.ReadTimeout := 10000;  // 10 segundos

    try
      Cliente.Connect;
      Cliente.WriteLn(string(Comando)); //comando'GET_CONTABIL'

      Resultado := '';
      if Cliente.Connected then
      begin
        repeat
          Linha := Cliente.ReadLn;
          if Linha = 'END' then Break;

          Resultado := Resultado + Linha + #13#10;
        until False;

        Cliente.Disconnect;

        // Retorna resultado como PChar
        if ( System.Pos('TOKEN', Resultado) = 0 ) then // N�o Encontrou
          Resposta := AllocPChar(Resultado)
        else
          Resposta := AllocPChar('');
      end;

    except
      on E: Exception do
      begin
        Erro := AllocPChar(E.ClassName + ': ' + E.Message);
     end;
    end;

  finally
    Cliente.Free;
  end;
end;

// Libera mem�ria de um PChar alocado pela DLL
procedure LiberarPChar(P: PChar); stdcall;
begin
  if P <> nil then
    StrDispose(P);
end;

exports
  EnviarComandoTCP,
  LiberarPChar;

begin
  if GStack = nil then
    GStack := TIdStack.Create; // inicializa o Indy aqui
end.
