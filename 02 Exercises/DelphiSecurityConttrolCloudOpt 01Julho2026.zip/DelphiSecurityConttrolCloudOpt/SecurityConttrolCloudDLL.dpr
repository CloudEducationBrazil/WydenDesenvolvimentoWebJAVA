library SecurityConttrolCloudDLL;

uses
  Windows, SysUtils, Classes, IniFiles, Dialogs, EncdDecd, Registry;

//{$H-} compat�vel com Delphi para ShortString; Delphi 7 AnsiString
{$H+}

type
  PIP_ADAPTER_INFO = ^TIP_ADAPTER_INFO;

  TIP_ADAPTER_INFO = record
    Next: PIP_ADAPTER_INFO;
    ComboIndex: DWORD;
    AdapterName: array[0..259] of Char;
    Description: array[0..131] of Char;
    AddressLength: UINT;
    Address: array[0..7] of Byte;
    Index: DWORD;
    _Type: UINT;
    DhcpEnabled: UINT;
    CurrentIpAddress: Pointer;
    IpAddressList: array[0..1] of Char;
    GatewayList: array[0..1] of Char;
    DhcpServer: array[0..1] of Char;
    HaveWins: BOOL;
    PrimaryWinsServer: array[0..1] of Char;
    SecondaryWinsServer: array[0..1] of Char;
    LeaseObtained: Integer;
    LeaseExpires: Integer;
  end;

function GetAdaptersInfo(
  AdapterInfo: PIP_ADAPTER_INFO;
  var BufLen: ULONG): DWORD; stdcall;

external 'iphlpapi.dll' name 'GetAdaptersInfo';

const
  // Vari�veis Note Heleno
   {ipHost   = '192168048'; // Host Server Cloud
   macHost  = '14-CB-64-63-A9-F8'; // Mac Ethernet Server Cloud invertido
   nameHost = 'inspiron'; // Nome do Host Server Windows
   secretWord = 'conttrolSecurityCloud'; // Palavra Secreta
   }
   
  // Vari�veis Server Cloud Opt Conttroller ou pegar no Registro do Windows Server ou na LIBFUNCS: ipHost; macHost; nameHost; SecretWord
  ipHost   = '10151100'; // Host Server Cloud IP Host VM 10.15.1.100
  macHost  = '02-00-CE-07-03-02'; // Mac Ethernet 02-03-07-CE-00-02 Server Cloud invertido
  nameHost = 'srvadds'; // Nome do Host Server Windows
  secretWord = 'conttrolSecurityCloud'; // Palavra Secreta
  
var
  listaCNPJ  : TStringList;
  listaDrive : TStringList;

  statusINI : string = '';
  nomeExe : string = '';
  sistema : string = '';

function LerChaveRegistro: string;
var
  Reg: TRegistry;
begin
  Result := '';

  Reg := TRegistry.Create;
  try
    Reg.RootKey := HKEY_LOCAL_MACHINE;

    if Reg.OpenKeyReadOnly(
      '\SOFTWARE\SecurityConttrolCloud') then
      Result := Reg.ReadString('SecurityKey');

  finally
    Reg.Free;
  end;
end;

function XORCrypt(const Texto, Chave: string): string;
var
  I, KeyLen: Integer;
begin
  Result := Texto;

  KeyLen := Length(Chave);

  for I := 1 to Length(Texto) do
  begin
    Result[I] := Char(
      Byte(Texto[I]) xor
      Byte(Chave[((I - 1) mod KeyLen) + 1])
    );
  end;
end;

function Criptografar(const Texto, Chave: string): string;
begin
  Result := EncodeString(    // Base64Encode
              XORCrypt(Texto, Chave)
            );
end;

function Descriptografar(const Texto, Chave: string): string;
begin
  Result := XORCrypt(
              DecodeString(Texto), Chave   // Base64Decode
            );
end;

function GerarHash(const Texto: string): string;
var
  I: Integer;
  Soma: LongInt;
begin
  Soma := 0;

  for I := 1 to Length(Texto) do
    Soma := Soma + Ord(Texto[I]) * I;

  Result := IntToHex(Soma, 8);
end;

function GetNomeComputador: string;
var
  Buffer: array[0..255] of Char;
  Size  : DWORD;
begin
  Size := SizeOf(Buffer);
  GetComputerName(Buffer, Size);

  Result := LowerCase(Trim(Buffer));
end;

function GetMacAddressInvertido: string;
var
  AdapterInfo : PIP_ADAPTER_INFO;
  BufLen      : ULONG;
  Status      : DWORD;
  Temp        : PIP_ADAPTER_INFO;
  i           : Integer;
  Mac         : string;
begin
  Result := '';

  BufLen := SizeOf(TIP_ADAPTER_INFO) * 16;
  GetMem(AdapterInfo, BufLen);

  try
    Status := GetAdaptersInfo(AdapterInfo, BufLen);

    if Status = ERROR_SUCCESS then
    begin
      Temp := AdapterInfo;

      while Temp <> nil do
      begin
        if Temp^.AddressLength > 0 then
        begin
          Mac := '';

          // MAC Invertido
          for i := Temp^.AddressLength - 1 downto 0 do
          begin
            Mac := Mac + IntToHex(Temp^.Address[i], 2);

            if i > 0 then
              Mac := Mac + '-';
          end;

          Result := UpperCase(Mac);
          Break;
        end;

        Temp := Temp^.Next;
      end;
    end;

  finally
    FreeMem(AdapterInfo);
  end;
end;

procedure CarregarListasFixas;
begin
  listaCNPJ  := TStringList.Create;
  listaDrive := TStringList.Create;

  // Para Novos CLIENTES CONTTROLLER Mesma posi��o, �ndice do StringList.

  { Listas CNPJs com Drives Autorizados }

  // Cliente Teste Ficticio Notebook Heleno
  listaCNPJ.Add('53760752000117');
  listaDrive.Add('P:');

  // Cliente LAAGE - FOLHA
  listaCNPJ.Add('13110889000101');
  listaDrive.Add('E:');

  // Cliente CONTABILIDADE 2 PONTO - FISCAL/CONTABIL/FOLHA
  listaCNPJ.Add('45802728000175');
  listaDrive.Add('H:');
end;

function EmpresaAutorizada(cnpjINI, driverINI: string): Boolean;
var
  i: Integer;
begin
  Result := False;

  for i := 0 to listaCNPJ.Count - 1 do
  begin
    if (Trim(listaCNPJ[i]) = Trim(cnpjINI)) and
       (UpperCase(Trim(listaDrive[i])) = UpperCase(Trim(driverINI))) then
    begin
      Result := True;
      Exit;
    end;
  end;
end;

function ValidarSistema: Boolean; //stdcall;
var
  Ini             : TIniFile;
  Caminho         : string;

  cnpjINI         : string;
  driverINI       : string;
  // statusINI : string;

  hostAutorizado  : string;
  hostAcessando   : string;

  nomeWindows     : string;

  macAddressInvertido : string;

  hastPalavraChave : string;
begin
  Result := True;

  CarregarListasFixas;

  try
    Caminho := ExtractFilePath(ParamStr(0)) + '@conttrl.ini';

    if not FileExists(Caminho) then
    begin
      Result := False;
      Exit;
    end;

    Ini := TIniFile.Create(Caminho);

    try
      cnpjINI   := Ini.ReadString('NET', 'Cnpj', '');
      driverINI := Ini.ReadString('NET', 'Driver', '');
      statusINI := Ini.ReadString('NET', 'Status', '');

    finally
      Ini.Free;
    end;

    //  Nome do Computador no WINDOWS
    nomeWindows := GetNomeComputador;

    // Palavra Chave - HASH
    hastPalavraChave := GerarHash(secretWord);
    // hastPalavraChave := GerarHash(LerChaveRegistro); // Pegando a palavra CHAVE do registro do Windows

    // HOST Autorizado
    hostAutorizado := Criptografar(
        ipHost +
        UpperCase(macHost) +
        LowerCase(nameHost), hastPalavraChave );

    // HOST Acessando
    macAddressInvertido := GetMacAddressInvertido;

    hostAcessando := Criptografar(
        ipHost +
        macAddressInvertido +
        nomeWindows, hastPalavraChave );

    // Valida HOST
    if hostAutorizado <> hostAcessando then
      Result := False
    else // Valida CNPJ + DRIVE
    if not EmpresaAutorizada(cnpjINI, driverINI) then
      Result := False
    else if ( statusINI = 'I' ) then // Status: I - Inativo; S - Suspenso; G - Pend�ncia financeira; N - Financeiro OK
    begin
      Result := False;
      ShowMessage('Identificamos que a LICEN�A DE USO para seu CNPJ n�o est� ATIVADA.!');
    end
    else if ( statusINI = 'S' ) then
    begin
      Result := False;
      ShowMessage('Identificamos que a LICEN�A DE USO para seu CNPJ precisa ser renovada.!');
    end
    else if ( uppercase(statusINI) <> 'G' ) and ( uppercase(statusINI) <> 'N' ) then
    begin
      Result := False;
      ShowMessage('Status Desconhecido, revise no @conttrl.ini.!');
    end;
    //else
    //  ShowMessage('Acesso autorizado!');

  finally
    listaCNPJ.Free;
    listaDrive.Free;
  end;
end;

procedure EnviarComandoTCP(
  Host: PChar;
  Port: Integer;
  const Comando: PChar;
  var Resposta: PChar;
  var Erro: PChar
); stdcall;
begin
  if not ValidarSistema then
  begin
    Resposta := nil;
    //ShowMessage('Acesso N�O Autorizado ...');
    Erro := StrNew('Acesso N�O Autorizado');
    Exit;
  end;
  //  else
  //    ShowMessage('Acesso Autorizado ...')

  NomeExe := uppercase(copy(ExtractFileName(ParamStr(0)), 1, 3));
  if NomeExe = 'SCG' then
    sistema := 'CONTABIL;'
  else
  if NomeExe = 'SLF' then
    sistema := 'FISCAL;'
  else
  if NomeExe = 'SFP' then
    sistema := 'FOLHA;';

  Resposta := StrNew(PChar(sistema + '2026-12-15T12:13:33.105951-03:00;A;' + statusINI));
  Erro := nil;
end;

// Libera mem�ria de um PChar alocado pela DLL
procedure LiberarPChar(P: PChar); stdcall;
begin
  if P <> nil then
    StrDispose(P);
end;

exports
  EnviarComandoTCP,
  LiberarPChar;

begin
  //
end.
