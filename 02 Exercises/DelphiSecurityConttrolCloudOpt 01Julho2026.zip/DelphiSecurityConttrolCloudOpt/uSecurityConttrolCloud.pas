unit uSecurityConttrolCloud;

interface

uses
  Windows, SysUtils, Classes, IniFiles, Dialogs, uCripto; // IpHlpApi

function ValidarSistema(): Boolean;

implementation

type
  PIP_ADAPTER_INFO = ^TIP_ADAPTER_INFO;

  TIP_ADAPTER_INFO = record
    Next: PIP_ADAPTER_INFO;
    ComboIndex: DWORD;
    AdapterName: array[0..259] of Char;
    Description: array[0..131] of Char;
    AddressLength: UINT;
    Address: array[0..7] of Byte;
    Index: DWORD;
    _Type: UINT;
    DhcpEnabled: UINT;
    CurrentIpAddress: Pointer;
    IpAddressList: array[0..1] of Char;
    GatewayList: array[0..1] of Char;
    DhcpServer: array[0..1] of Char;
    HaveWins: BOOL;
    PrimaryWinsServer: array[0..1] of Char;
    SecondaryWinsServer: array[0..1] of Char;
    LeaseObtained: Integer;
    LeaseExpires: Integer;
  end;

function GetAdaptersInfo(
  AdapterInfo: PIP_ADAPTER_INFO;
  var BufLen: ULONG): DWORD; stdcall;

external 'iphlpapi.dll' name 'GetAdaptersInfo';

const
  ipHost   = '192168048'; // Host Server Cloud
  macHost  = '14-CB-64-63-A9-F8'; // Mac Ethernet Server Cloud invertido
  nameHost = 'inspiron'; // Nome do Host Server Windows   

var
  listaCNPJ  : TStringList;
  listaDrive : TStringList;

function GetNomeComputador: string;
var
  Buffer: array[0..255] of Char;
  Size  : DWORD;
begin
  Size := SizeOf(Buffer);
  GetComputerName(Buffer, Size);

  Result := LowerCase(Trim(Buffer));
end;

function GetMacAddressInvertido: string;
var
  AdapterInfo : PIP_ADAPTER_INFO;
  BufLen      : ULONG;
  Status      : DWORD;
  Temp        : PIP_ADAPTER_INFO;
  i           : Integer;
  Mac         : string;
begin
  Result := '';

  BufLen := SizeOf(TIP_ADAPTER_INFO) * 16;
  GetMem(AdapterInfo, BufLen);

  try
    Status := GetAdaptersInfo(AdapterInfo, BufLen);

    if Status = ERROR_SUCCESS then
    begin
      Temp := AdapterInfo;

      while Temp <> nil do
      begin
        if Temp^.AddressLength > 0 then
        begin
          Mac := '';

          // MAC INVERTIDO
          for i := Temp^.AddressLength - 1 downto 0 do
          begin
            Mac := Mac + IntToHex(Temp^.Address[i], 2);

            if i > 0 then
              Mac := Mac + '-';
          end;

          Result := UpperCase(Mac);
          Break;
        end;

        Temp := Temp^.Next;
      end;
    end;

  finally
    FreeMem(AdapterInfo);
  end;
end;

function ValidaDrive: string;
var
  Drive: string;
begin
  Drive := ExtractFileDrive(ParamStr(0));

  Result := Drive;
end;

procedure CarregarListasFixas;
begin
  listaCNPJ  := TStringList.Create;
  listaDrive := TStringList.Create;

  // MESMA POSI��O = MESMO CLIENTE CONTTROLLER

  // listas de CNPJs com Drives autorizados
  listaCNPJ.Add('01325433000190');
  listaDrive.Add('P:');

  listaCNPJ.Add('99999999000199');
  listaDrive.Add('D:');
end;

function EmpresaAutorizada(cnpjINI, driverINI: string): Boolean;
var
  i: Integer;
begin
  Result := False;

  for i := 0 to listaCNPJ.Count - 1 do
  begin
    if (Trim(listaCNPJ[i]) = Trim(cnpjINI)) and
       (UpperCase(Trim(listaDrive[i])) = UpperCase(Trim(driverINI))) then
    begin
      Result := True;
      Exit;
    end;
  end;
end;

function ValidarSistema: Boolean;
var
  Ini             : TIniFile;
  Caminho         : string;

  cnpjINI         : string;
  driverINI       : string;
  statusINI       : string;

  hostAutorizado  : string;
  hostAcessando   : string;

  nomeWindows     : string;

  macAddressInvertido : string;

  hastPalavraChave : string;
begin
  Result := True;

  CarregarListasFixas;

  try
    Caminho := ExtractFilePath(ParamStr(0)) + '@conttrl.ini';

    if not FileExists(Caminho) then
    begin
      Result := False;
      Exit;
    end;

    Ini := TIniFile.Create(Caminho);

    try
      cnpjINI   := Ini.ReadString('NET', 'Cnpj', '');
      driverINI := Ini.ReadString('NET', 'Driver', '');
      statusINI := Ini.ReadString('NET', 'Status', '');

    finally
      Ini.Free;
    end;

    //  NOME DO WINDOWS
    nomeWindows := GetNomeComputador;

    // Palavra Chave - Hash - melhoria hash SHA1/MD5
    hastPalavraChave := GerarHash('conttrolSecurityCloud');

    // HOST AUTORIZADO
    hostAutorizado := Criptografar(
        ipHost +
        UpperCase(macHost) +
        LowerCase(nameHost), hastPalavraChave );

    // HOST ACESSANDO
    macAddressInvertido := GetMacAddressInvertido;

    hostAcessando := Criptografar(
        ipHost +
        macAddressInvertido +
        nomeWindows, hastPalavraChave );

    // VALIDA HOST
    if hostAutorizado <> hostAcessando then
      Result := False
    else // VALIDA CNPJ + DRIVE
    if not EmpresaAutorizada(cnpjINI, driverINI) then
      Result := False
    else if ( statusINI = 'I' ) then // Status: I - Inativo; S - Suspenso; G - Pend�ncia financeira; N - Financeiro OK
    begin
      Result := False;
      ShowMessage('Identificamos que a LICEN�A DE USO para seu CNPJ n�o est� ATIVADA.!');
    end
    else if ( statusINI = 'S' ) then
    begin
      Result := False;
      ShowMessage('Identificamos que a LICEN�A DE USO para seu CNPJ precisa ser renovada.!');
    end
    else if ( uppercase(statusINI) <> 'G' ) and ( uppercase(statusINI) <> 'N' ) then
    begin
      Result := False;
      ShowMessage('Status Desconhecido, revise no @conttrl.ini.!');
    end;
    //else
    //  ShowMessage('Acesso autorizado!');

  finally
    listaCNPJ.Free;
    listaDrive.Free;
  end;
end;

end.
