unit uTeste;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

  // function ValidarSistema: Boolean; stdcall; external 'SecurityConttrolCloudDLL.dll';
  procedure EnviarComandoTCP(const Host: PChar; Port: Integer; const Comando: PChar; var Resposta: PChar; var Erro: PChar); stdcall; external 'SecurityConttrolCloudDLL.dll';

type
  TForm1 = class(TForm)
    Button1: TButton;
    procedure Button1Click(Sender: TObject);

  private
    { Private declarations }

  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.Button1Click(Sender: TObject);
var sResposta, sErro : PChar;
begin
  //if ValidarSistema then
  //  ShowMessage('Acesso Autorizado ...')
  //else
  //  ShowMessage('Acesso N�O Autorizado ...');
  sResposta := nil;
  sErro := nil;

  EnviarComandoTCP(Pchar('127.0.0.1'), 8888, Pchar('GET_CLOUD'), sResposta, sErro);
end;

end.
