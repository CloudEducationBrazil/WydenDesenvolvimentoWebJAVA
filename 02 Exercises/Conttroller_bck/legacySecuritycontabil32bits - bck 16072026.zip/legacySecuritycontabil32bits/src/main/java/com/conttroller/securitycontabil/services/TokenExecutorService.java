package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.dto.TokenEnvioApiContabilidadeDTO;
import com.conttroller.securitycontabil.dto.TokenRetornoApiContabilidadeDTO;
import com.conttroller.securitycontabil.entities.Token;
import com.conttroller.securitycontabil.execution.ExecutionControl;
import com.conttroller.securitycontabil.repositories.TokenRepository;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

//import javax.swing.text.MaskFormatter;

import java.time.*;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Service
public class TokenExecutorService {
    private static final Logger logger = LoggerFactory.getLogger(TokenExecutorService.class);

	private final TokenPersistenceService tokenPersistenceService;
    private final TokenService tokenService;
    private final EmailSender emailSender;
    private final AppContextService contextService;
    private final ExecutionControl executionControl;
    private final TokenRepository tokenRepository;
    
    public TokenExecutorService(TokenPersistenceService tokenPersistenceService,
                                TokenService tokenService,
                                EmailSender emailSender,
                                AppContextService contextService,
                                ExecutionControl executionControl,
                                TokenRepository tokenRepository) {
        this.tokenPersistenceService = tokenPersistenceService;
        this.tokenService = tokenService;
        this.emailSender = emailSender;
        this.contextService = contextService;
        this.executionControl = executionControl;
        this.tokenRepository = tokenRepository;
    }
    
    @PostConstruct
    public void inicializarSeguranca() {
        try {
            if (isStorageEmpty()) {
               logger.warn("H2 está vazio na inicialização. Restaurando tokens do Registro...");

               //long antes = tokenRepository.count();
               executionControl.restoreFromRegistry();
               //long depois = tokenRepository.count();

               // logger.info("[AUDITORIA] Tokens restaurados do Registro. Total restaurado: {}", (depois - antes));
               logger.info("[AUDITORIA] Tokens restaurados do Registro.");
            } else {
                logger.info("H2 já possui tokens. Nenhuma restauração necessária.");
            }
        } catch (Exception e) {
            logger.error("Falha na inicialização segura do H2: {}", e.getMessage(), e);
        }
    }
 
    /** Chamado pelo Scheduler */
    public void executarTokenReal() {
        try {
            // Chamado pelo Scheduler 
        	salvarTokensTransacionado();
	        carregarTokenDaApiComRetry();

        } catch (Exception e) {
            logger.error("Erro ao executar token real.", e); // , e
            //logger.error("Erro ao executar token real: {}", e.getMessage()); // , e
        }
    }

    @Transactional
    public void salvarTokensTransacionado() {
    	try {
	        List<Token> tokens = tokenService.carregarTokensParaExecutor();
	        tokens.forEach(tokenPersistenceService::salvarOuAtualizar);
	        
	        logger.info("Tokens locais [HD] salvos/atualizados com sucesso.");
    	}
    	catch (Exception e) {
	        logger.error("Não foi possível salvar Tokens locais [HD] {}.", e.getMessage());
		}
    }
    
    /**
     * Consome a API para atualizar token oficial com retry simples
    */
    private void carregarTokenDaApiComRetry() {
    	
        String cnpj = contextService.getCnpj();
        if (cnpj == null || cnpj.isBlank()) {
            logger.warn("CNPJ não definido. Não é possível carregar token da API.");
            return;
        }
        
    	int tentativas = 3;
        for (int i = 1; i <= tentativas; i++) {
            try {
            	logger.info("[TOKEN][API] Tentativa {} de {} para carregar Token da AZURE...", i, tentativas);
            	
                //TokenRetornoApiContabilidadeDTO retorno = carregarTokenDaApi(cnpj, new TokenEnvioApiContabilidadeDTO(cnpj, contextService.getInputToken() != null ? contextService.getInputToken() : ""));
                TokenRetornoApiContabilidadeDTO retorno = carregarTokenDaApi(cnpj, new TokenEnvioApiContabilidadeDTO(cnpj, contextService.getInputToken() != null ? contextService.getInputToken() : ""));
                
                if (retorno != null) {
                    logger.info("[TOKEN][API] Token atualizado com sucesso na tentativa {}/{}", i, tentativas);
                    return;
                }
                
            } catch (Exception e) {
                logger.warn("[TOKEN][API] Falha ao obter da API AZURE na tentativa {}/{}: {}", i, tentativas, e.getMessage());
            }
            
            logger.warn("[TOKEN][API] Aguardando {}s antes de nova tentativa...", 5);
            try {
                Thread.sleep(5000); // 5s antes da próxima tentativa de consultar a API AZURE
            } catch (InterruptedException ignored) {Thread.currentThread().interrupt();}
        }
        
        logger.error("[TOKEN][API] Todas as tentativas de obter token da API AZURE falharam.");
        
        try {
            logger.warn("[TOKEN][API] API AZURE indisponível. Restaurando tokens do Registro do Windows...");
            
            executionControl.restoreFromRegistry();
            
            logger.info("[TOKEN][WINDOWS] Restauração concluída com sucesso.");
            
        } catch (Exception e) {
            logger.error("[TOKEN][WINDOWS] Falha ao restaurar tokens do Registro: {}", e.getMessage());
        }        
    }

    public boolean isServiceInstalled(String serviceName) {
        try {
            Process process = new ProcessBuilder("sc", "query", serviceName).start();
            int exitCode = process.waitFor();
            
            return exitCode == 0; // serviço TokenService existe
        } catch (Exception e) {
            logger.error("Erro ao verificar serviço {}: {}", serviceName, e.getMessage());
            return false;
        }
    }   
    
    /** Registra o serviço no Windows usando NSSM */
    /* public void executarRegistroService(String diretorToken) throws IOException, InterruptedException {
        String serviceName = "TokenService";
        String jarPath = contextService.getCaminho() + "\\securitycontabil.jar";

        // Detecta arquitetura do SO
        String osArch = System.getProperty("os.arch").contains("64") ? "nssm64.exe" : "nssm32.exe";

        // NSSM dentro do JAR, extrair para pasta temporária
        Path tempDir = Files.createTempDirectory("nssm");
        Path nssmExe = tempDir.resolve(osArch);

        try (InputStream is = getClass().getResourceAsStream("/nssm/" + osArch)) {
            Files.copy(is, nssmExe);
        }

        // Comando para instalar o serviço via NSSM
        String[] cmdInstall = {
                nssmExe.toString(),
                "install", serviceName,
                "java", "-jar", jarPath, diretorToken
        };

        ProcessBuilder pbInstall = new ProcessBuilder(cmdInstall);
        pbInstall.inheritIO();
        Process processInstall = pbInstall.start();
        int exitInstall = processInstall.waitFor();
        if (exitInstall == 0) {
        	logger.info("Serviço criado com sucesso via NSSM.");
        } else {
        	logger.error("Falha ao criar serviço. Código: " + exitInstall);
            return;
        }

        // Inicia o serviço
        String[] cmdStart = {nssmExe.toString(), "start", serviceName};
        ProcessBuilder pbStart = new ProcessBuilder(cmdStart);
        pbStart.inheritIO();
        Process processStart = pbStart.start();
        int exitStart = processStart.waitFor();
        if (exitStart == 0) {
        	logger.info("Serviço iniciado com sucesso via NSSM.");
        } else {
        	logger.error("Falha ao iniciar serviço. Código: " + exitStart);
        }
    }
    */
    
    /**
     * Carrega o token oficial da API para atualizar H2 e registro do Windows.
    */
    public TokenRetornoApiContabilidadeDTO carregarTokenDaApi(String cnpj, TokenEnvioApiContabilidadeDTO envioDto) {
        try {
            // Chama a API e retorna o DTO completo
            TokenRetornoApiContabilidadeDTO retornoDto = tokenService.postTokenContabilidade(envioDto);
            
            // Salvar empresa como var memória
            if (retornoDto != null && retornoDto.getServidor() != null) { // 06/07/2026 Heleno
	            contextService.setEmpresa(retornoDto.getServidor().getNome());
	            
	            try {
	            	if (!executionControl.isFirstRun() && tokenService.getMsg() != null && !tokenService.getMsg().isEmpty()) {
	                    logger.warn("Email Divergência Token Conttroller vs Implantação: {}", tokenService.getMsg().toString());
	            		enviarTokenEmail(contextService.getCnpj(), tokenService.getMsg());
	                }
	    			
	    		} catch (Exception e) {
	                logger.warn("Falha envio email, divergência Token ativação: {}", e.getMessage());
	    		}
            } // 06/07/2026 Heleno 
            else {

                logger.warn("API retornou Servidor nulo. Não foi possível identificar a empresa.");

                return null;
            }
            
            logger.info("Token oficial obtido da API com sucesso.");
            return retornoDto;

        } catch (feign.FeignException e) {
        	
            int status = e.status(); // StatusHTTP = 0 / 200 - OK, pode continuar chamando a API.

            if (status == 400) { // logger.error("Erro 401 (Unauthorized) — API requer autenticação.");
                logger.error("Erro 400 (Bad Request) — Requisição inválida ou token não encontrado.");
            } else if (status == 403) {
                logger.error("Erro 403 (Forbidden) — Acesso negado.");
            } else if (status == 404) {
                logger.error("Erro 404 (Not Found) — Recurso não encontrado.");
            } else if (status == 405) {
                logger.error("Erro 405 — método HTTP não permitido.");
            } else if (status >= 400 && status < 500) {
                logger.warn("Erro inesperado na chamada da API 4xx: {} - {}", status, e.getMessage());
            } else if (status >= 500) {
                logger.error("Erro inesperado na chamada da API 5xx, API instável: {} - {}", status, e.getMessage());
            }
            
            contextService.setStatusHTTP(status);

            return null;

        } catch (Exception e) {
            logger.error("Falha ao obter token oficial da API.", e); //, e
            return null;
        }
    }
    
    public boolean isStorageEmpty() {
        return tokenRepository.count() == 0; // verifica se tabela token no BD H2 está vazia
    }   

    /** Gera token temporário para primeira execução */
    public String gerarToken() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    /** Envia token por e-mail */
    public void enviarTokenEmail(String cnpj, String token) throws Exception {
    	
    	String ip = "(não disponível)";
    	String cidade = "(não disponível)";
    	String cep = "(não disponível)";
    	String pais = "(não disponível)";
    	String regiao = "(não disponível)";
    	String lat = "(não disponível)";
    	String lon = "(não disponível)";
    	
    	// https://iplocation.io/ip/187.44.228.230
    	LocalizacaoService.LocalizacaoCompleta info = null;
    	
    	try {
    	    info = LocalizacaoService.getLocalizacaoCompleta();
    	} catch (Exception e) {
    	    logger.warn("Não foi possível obter a localização de implantação.", e);
    	}

    	if (info != null && info.geo != null) {
        	// ==============================
        	// NORMALIZA CAMPOS (SEM NULL)
        	// ==============================

        	// GEO
        	ip = empty(info.ip);
        	cidade = empty(info.geo.city);
        	cep    = empty(info.geo.zip);
        	pais   = empty(info.geo.country);
        	regiao = empty(info.geo.region);
        	lat    = empty(info.geo.lat);
        	lon    = empty(info.geo.lon);
    	}
    	else {
    	    logger.warn("Não foi possível obter a geolocalização da máquina.");
    	}    	
    	
    	logger.info("IP: {}", ip);
    	logger.info("Cidade: {}", cidade);
    	logger.info("CEP: {}", cep);

    	// ENDEREÇO
    	// String logradouro = empty(info.endereco.logradouro);
    	// String bairro     = empty(info.endereco.bairro);
    	// String uf         = empty(info.endereco.estado);

    	// logger.info("Logradouro: {}", logradouro);
    	// logger.info("Bairro: {}", bairro);
    	// logger.info("UF: {}", uf);

    	// Monta texto do e-mail
		String location = new StringBuilder()
		    .append("<div style=\"margin-top: 10px; line-height: 1.6;\">")
	
		    .append("<div><b>Localização da máquina no momento da geração do token:</b></div>")
		    .append("<div>A aplicação Java enviou automaticamente as seguintes informações:</div>")
		    .append("<br>")
	
		    .append("<div><b>IP Público:</b> ").append(ip).append("</div>")
		    .append("<div><b>País:</b> ").append(pais).append("</div>")
		    .append("<div><b>Região:</b> ").append(regiao).append("</div>")
		    .append("<div><b>Cidade:</b> ").append(cidade).append("</div>")
		    .append("<div><b>CEP:</b> ").append(cep).append("</div>")
		    .append("<div><b>Latitude:</b> ").append(lat).append("</div>")
		    .append("<div><b>Longitude:</b> ").append(lon).append("</div>")
	
		    .append("</div>")
		    .toString();
		
			//Logradouro: %s
			//Bairro: %s
			//UF: %s
    	
    	String dataHoraAtual = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")
    	        .withZone(ZoneId.systemDefault())
    	        .format(Instant.now());
    	
    	String saudacao;
    	LocalTime agora = LocalTime.now();

    	if (agora.isAfter(LocalTime.of(5, 0)) && agora.isBefore(LocalTime.of(12, 0))) {
    	    saudacao = "bom dia";
    	} else if (agora.isBefore(LocalTime.of(18, 0))) {
    	    saudacao = "boa tarde";
    	} else {
    	    saudacao = "boa noite";
    	}
    	
    	String empresa = contextService.getEmpresa();

		if (empresa == null || empresa.trim().isEmpty()) {
		    empresa = "Empresa Sem Contrato";
		}
		
		//MaskFormatter mf = new MaskFormatter("##.###.###/####-##");
		//mf.setValueContainsLiteralCharacters(false);
		
		String cnpjFormatado = formatarCnpj(cnpj);
	    	
		String corpo = new StringBuilder()
			    .append("<html>")
			    .append("<body style=\"font-family: Arial, sans-serif; color: #333;\">")
			    .append("<p>Prezado, ").append(saudacao).append(".</p>")
			    .append("<p>Segue abaixo o token para a implantação do sistema contábil Win 32bits:</p>")

			    .append("<div style=\"margin-top: 10px; line-height: 1.6;\">")
			    .append("<div><b>Data/Hora:</b> ").append(dataHoraAtual).append("</div>")
			    //.append("<div><b>CNPJ:</b> ").append(mf.valueToString(cnpj)).append("</div>")
			    .append("<div><b>CNPJ:</b> ").append(cnpjFormatado).append("</div>")
			    .append("<div><b>Empresa:</b> ").append(empresa).append("</div>")
			    .append("<div><b>Token:</b> <span style=\"color: #0B5394; font-weight: bold;\">")
			    .append(token)
			    .append("</span></div>")
			    .append("</div>")
			    
			    .append("<div><b>Localização da máquina no momento da geração do token:</b> <span style=\"color: #0B5394; font-weight: bold;\">")
			    .append(location)
			    .append("</span></div>")
			    .append("</div>")

			    .append("<br>")
			    .append("<p>Att.,</p>")
			    .append("<p><b>Jean Venezia</b><br>")
			    .append("Diretor de TI</p>")
			    .append("</body>")
			    .append("</html>")
			    .toString();
		
		// if (!mf.valueToString(cnpj).equals("00.000.000/0000-00")) {
		//if (!"00.000.000/0000-00".equals(cnpjFormatado)) {
		if (!"00000000000000".equals(somenteNumeros(cnpj))) {
	         //emailSender.sendEmail("jeanvenezia@gmail.com", "Token: " + mf.valueToString(cnpj) + " - " + empresa, corpo);
			logger.info("Enviando e-mail para implantação do TOKEN, Send!");
	        emailSender.sendEmail("jeanvenezia@gmail.com", "Token: " + cnpjFormatado + " - " + empresa, corpo);
	        //emailSender.sendEmail("helenocardosofilho@gmail.com", "Token - " + mf.valueToString(cnpj) + " - " + empresa, corpo);
		    logger.info("E-mail com o TOKEN enviado para a Conttroller, Send!");
		}
    }
    
	// Função auxiliar
	private static String empty(String value) {
	    return (value == null || value.isBlank()) ? "(não disponível)" : value;
	}    

    public void restaurarTokensDoRegistro() {
    	if (isStorageEmpty()) {
    	    logger.warn("H2 está vazio. Restaurando tokens do Registro...");
    	    executionControl.restoreFromRegistry();
    	}
    	
    	// executionControl.restoreFromRegistry();
    }
    
    public void atualizarJSONParaProducao() {
        try {
            TokenEnvioApiContabilidadeDTO envioDto = 
      		  new TokenEnvioApiContabilidadeDTO(contextService.getCnpj(), contextService.getInputToken() != null ? contextService.getInputToken() : "");

            //tokenService.postTokenContabilidade(envioDto);
            
            // 06/07/2026 Heleno
            TokenRetornoApiContabilidadeDTO dto =
                    tokenService.postTokenContabilidade(envioDto);

            if (dto == null) {
                logger.warn("API AZURE não retornou dados.");
                return;
            }              
            
            logger.info("Tokens atualizados com sucesso para produção.");
        } catch (Exception e) {
            logger.error("Falha ao atualizar tokens para produção.", e); //, e
        }
    }
    
    public static String formatarCnpj(String cnpj) {
        String n = somenteNumeros(cnpj);
        if (n.length() != 14) return cnpj;
        return n.replaceFirst(
            "(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})",
            "$1.$2.$3/$4-$5"
        );
    }

    private static String somenteNumeros(String valor) {
        return valor == null ? "" : valor.replaceAll("\\D", "");
    }    
}