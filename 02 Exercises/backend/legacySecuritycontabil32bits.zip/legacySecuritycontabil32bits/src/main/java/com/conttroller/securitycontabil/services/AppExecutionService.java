package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.components.AppTerminator;
import com.conttroller.securitycontabil.execution.ExecutionControl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class AppExecutionService {

    private static final Logger logger = LoggerFactory.getLogger(AppExecutionService.class);

    private final ExecutionControl executionControl;
    private final TokenExecutorService tokenExecutorService;
    private final AppContextService contextService;
    private final AppTerminator appTerminator;

    public AppExecutionService(
            ExecutionControl executionControl,
            TokenExecutorService tokenExecutorService,
            AppContextService contextService,
            AppTerminator appTerminator) {
        this.executionControl = executionControl;
        this.tokenExecutorService = tokenExecutorService;
        this.contextService = contextService;
        this.appTerminator = appTerminator;
    }

    public void executar() {
        String tokenFornecido = contextService.getInputToken();
 
        logger.info("[FISRT_RUN] isFirstRun : " + executionControl.isFirstRun());
        try {
            if (executionControl.isFirstRun()) {
                executarPrimeiraExecucao();
            } 
            else if (tokenFornecido != null && !tokenFornecido.isBlank()) {
	                logger.info("[SECOND_RUN] : chamando TokenExecutionService.atualizarTokesParaProducao");
	                //logger.warn("[VALIDAR TOKEN OK] " + validarERegistrarServico(tokenFornecido));

	                logger.info("[SERVICETOKEN] isServiceRun : " + executionControl.isServiceRun());
	                logger.info("[TOKEN FORNECIDO excutar] " + tokenFornecido);
	                
	                //if (validarERegistrarServico(tokenFornecido)) {
		            if (!executionControl.isServiceRun()) {
		            	
	                    tokenExecutorService.executarTokenReal();
	                    
	                    tokenExecutorService.enviarTokenEmail(contextService.getCnpj(), "Security Conttrol implantado no cliente.");
	                    
	                    executionControl.saveService(); // salva 1 = serviço instalado
	
	                    logger.info("[APP EXECUTION][SECOND_RUN] SERVICETOKEN : " + executionControl.isServiceRun());
	                }
	            	 else {
			                logger.info("[APP EXECUTION][NORMAL] SERVICETOKEN : " + executionControl.isServiceRun());
			                
			                logger.info("[APP EXECUTION][NORMAL] Execução normal: nenhuma ação de registro requerida.");
			                
			                tokenExecutorService.atualizarJSONParaProducao();
		             }
	             } 
        } catch (Exception e) {
            logger.error("[APP EXECUTION][FAIL EMAIL] Erro durante a execução: {}", e.getMessage()); //, e
            appTerminator.exit(1);
        }
    }

    private void executarPrimeiraExecucao() {
        try {
            logger.info("[APP EXECUTION][FIRST_RUN]");

            String tokenTemp = tokenExecutorService.gerarToken();
            executionControl.saveToken(tokenTemp);

            tokenExecutorService.executarTokenReal(); // Pega o nome da empresa
            
            tokenExecutorService.enviarTokenEmail(contextService.getCnpj(), tokenTemp);

            logger.info("[APP EXECUTION][FIRST_RUN][OK] Token enviado com sucesso.");
            //appTerminator.exit(0);
            appTerminator.exit(1);
        } catch (Exception e) {
            logger.error("[APP EXECUTION][FIRST_RUN][FAIL] Erro na primeira execução: {}", e.getMessage()); //, e
            appTerminator.exit(1);
        }
    }

//    private boolean validarERegistrarServico(String tokenFornecido) {
//        try {
//            String tokenArmazenado = executionControl.getStoredToken();
//            if (!tokenFornecido.equals(tokenArmazenado)) {
//                logger.error("[SECOND_RUN][FAIL] Token fornecido não corresponde ao registrado.");
//                return false;
//            }

//            tokenExecutorService.atualizarJSONParaProducao();
            
            // Gera problemas no serviço TokenService Windows
/*            String serviceName = "TokenService";
            if (!tokenExecutorService.isServiceInstalled(serviceName)) {
                logger.info("[{}] Serviço {} não encontrado. Iniciando instalação...", 
                            java.time.LocalDateTime.now(), serviceName);

                tokenExecutorService.executarRegistroService(tokenArmazenado);
                
                logger.info("[{}] Serviço {} instalado e iniciado com sucesso.", 
                            java.time.LocalDateTime.now(), serviceName);
            } else {
                logger.info("[{}] Serviço {} já instalado. Nenhuma ação necessária.", 
                            java.time.LocalDateTime.now(), serviceName);
            }       
*/
//            logger.info("[APP EXECUTION][SECOND_RUN][OK] Serviço registrado com sucesso.");
//            return true;
//        } catch (Exception e) {
//            logger.error("[APP EXECUTION][SECOND_RUN][FAIL] Falha ao validar token ou registrar serviço: {}", e.getMessage());
//        	return false;
//        }
//    }
}