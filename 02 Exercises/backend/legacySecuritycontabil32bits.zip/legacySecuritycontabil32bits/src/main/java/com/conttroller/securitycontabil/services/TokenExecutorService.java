package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.dto.TokenEnvioApiContabilidadeDTO;
import com.conttroller.securitycontabil.dto.TokenRetornoApiContabilidadeDTO;
import com.conttroller.securitycontabil.entities.Token;
import com.conttroller.securitycontabil.execution.ExecutionControl;
import com.conttroller.securitycontabil.repositories.TokenRepository;

import javax.annotation.PostConstruct;
import javax.swing.text.MaskFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//import java.io.IOException;
//import java.io.InputStream;
//import java.nio.file.Files;
//import java.nio.file.Path;

import java.util.List;
import java.util.UUID;

import java.time.*;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Service
public class TokenExecutorService {
    private static final Logger logger = LoggerFactory.getLogger(TokenExecutorService.class);

	private final TokenPersistenceService tokenPersistenceService;
    private final TokenService tokenService;
    private final EmailSender emailSender;
    private final AppContextService contextService;
    private final ExecutionControl executionControl;
    private final TokenRepository tokenRepository;
    
    public TokenExecutorService(TokenPersistenceService tokenPersistenceService,
                                TokenService tokenService,
                                EmailSender emailSender,
                                AppContextService contextService,
                                ExecutionControl executionControl,
                                TokenRepository tokenRepository) {
        this.tokenPersistenceService = tokenPersistenceService;
        this.tokenService = tokenService;
        this.emailSender = emailSender;
        this.contextService = contextService;
        this.executionControl = executionControl;
        this.tokenRepository = tokenRepository;
    }
    
    @PostConstruct
    public void inicializarSeguranca() {
        try {
            if (isStorageEmpty()) {
                logger.warn("H2 está vazio na inicialização. Restaurando tokens do Registro...");

                long antes = tokenRepository.count();
                executionControl.restoreFromRegistry();
                long depois = tokenRepository.count();

                logger.info("[AUDITORIA] Tokens restaurados do Registro. Total restaurado: {}", (depois - antes));
            } else {
                logger.info("H2 já possui tokens. Nenhuma restauração necessária.");
            }
        } catch (Exception e) {
            logger.error("Falha na inicialização segura do H2: {}", e.getMessage(), e);
        }
    }
 
    /** Chamado pelo Scheduler */
    public void executarTokenReal() {
        try {

        	// logger.info("SalvarTokens, chamado pelo Schedule.");
            
            // Tb Chamado pelo Scheduler 
        	salvarTokensTransacionado();
	        carregarTokenDaApiComRetry();

        } catch (Exception e) {
            logger.error("Erro ao executar token real: {}", e.getMessage()); // , e
        }
    }

    /** Transacional: salva/atualiza todos os tokens */
    @Transactional
    public void salvarTokensTransacionado() {
        List<Token> tokens = tokenService.carregarTokensParaExecutor();
        tokens.forEach(tokenPersistenceService::salvarOuAtualizar);
        
        logger.info("Tokens locais salvos/atualizados com sucesso.");
    }
    
    /**
     * Consome a API para atualizar token oficial com retry simples
     */
    private void carregarTokenDaApiComRetry() {
        int tentativas = 3;
        for (int i = 1; i <= tentativas; i++) {
            try {
                TokenRetornoApiContabilidadeDTO retorno = carregarTokenDaApi();
                if (retorno != null) {
                    logger.info("Token oficial obtido da API na tentativa {}/{}", i, tentativas);
                    return;
                }
            } catch (Exception e) {
                logger.warn("Falha ao obter token da API na tentativa {}/{}: {}", i, tentativas, e.getMessage());
            }
            try {
                Thread.sleep(5000); // 5s antes da próxima tentativa
            } catch (InterruptedException ignored) {}
        }
        logger.error("Não foi possível obter token da API após {} tentativas.", tentativas);
    }

    public boolean isServiceInstalled(String serviceName) {
        try {
            Process process = new ProcessBuilder("sc", "query", serviceName).start();
            int exitCode = process.waitFor();
            // Se exitCode == 0, serviço existe
            return exitCode == 0;
        } catch (Exception e) {
            logger.error("Erro ao verificar serviço {}: {}", serviceName, e.getMessage());
            return false;
        }
    }   
    
    /** Registra o serviço no Windows usando NSSM */
/*    public void executarRegistroService(String diretorToken) throws IOException, InterruptedException {
        String serviceName = "TokenService";
        String jarPath = contextService.getCaminho() + "\\securitycontabil.jar";

        // Detecta arquitetura do SO
        String osArch = System.getProperty("os.arch").contains("64") ? "nssm64.exe" : "nssm32.exe";

        // NSSM dentro do JAR, extrair para pasta temporária
        Path tempDir = Files.createTempDirectory("nssm");
        Path nssmExe = tempDir.resolve(osArch);

        try (InputStream is = getClass().getResourceAsStream("/nssm/" + osArch)) {
            Files.copy(is, nssmExe);
        }

        // Comando para instalar o serviço via NSSM
        String[] cmdInstall = {
                nssmExe.toString(),
                "install", serviceName,
                "java", "-jar", jarPath, diretorToken
        };

        ProcessBuilder pbInstall = new ProcessBuilder(cmdInstall);
        pbInstall.inheritIO();
        Process processInstall = pbInstall.start();
        int exitInstall = processInstall.waitFor();
        if (exitInstall == 0) {
        	logger.info("Serviço criado com sucesso via NSSM.");
        } else {
        	logger.error("Falha ao criar serviço. Código: " + exitInstall);
            return;
        }

        // Inicia o serviço
        String[] cmdStart = {nssmExe.toString(), "start", serviceName};
        ProcessBuilder pbStart = new ProcessBuilder(cmdStart);
        pbStart.inheritIO();
        Process processStart = pbStart.start();
        int exitStart = processStart.waitFor();
        if (exitStart == 0) {
        	logger.info("Serviço iniciado com sucesso via NSSM.");
        } else {
        	logger.error("Falha ao iniciar serviço. Código: " + exitStart);
        }
    }
*/    
    /**
     * Carrega o token oficial da API para atualizar H2 e registro do Windows.
     */
    public TokenRetornoApiContabilidadeDTO carregarTokenDaApi() {
        try {
            String cnpj = contextService.getCnpj();
            if (cnpj == null || cnpj.isBlank()) {
                logger.warn("CNPJ não definido. Não é possível carregar token da API.");
                return null;
            }

            // Monta o DTO para envio
            TokenEnvioApiContabilidadeDTO envioDto = new TokenEnvioApiContabilidadeDTO(cnpj, "", contextService.getCaminho());

            // Chama a API e retorna o DTO completo
            TokenRetornoApiContabilidadeDTO retornoDto = tokenService.postTokenContabilidade(envioDto);
            
            // Salvar empresa como var memória
            contextService.setEmpresa(retornoDto.getServidor().getNome());
            
            try {
                logger.warn("Email Divergência Token Conttroller vs Implantação: {}", tokenService.getMsg().toString());
                
            	if (tokenService.getMsg() != null && !tokenService.getMsg().isEmpty()) {
            		enviarTokenEmail(contextService.getCnpj(), tokenService.getMsg());
                }
    			
    		} catch (Exception e) {
                logger.warn("Falha envio email: {}", e.getMessage());
    		}
            
            logger.info("Token oficial obtido da API com sucesso.");
            return retornoDto;

        } catch (Exception e) {
            logger.error("Falha ao obter token oficial da API: {}", e.getMessage()); //, e
            return null;
        }
    }
    
    public boolean isStorageEmpty() {
        return tokenRepository.count() == 0; // verifica se tabela H2 está vazia
    }   

    /** Gera token temporário para primeira execução */
    public String gerarToken() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    /** Envia token por e-mail */
    public void enviarTokenEmail(String cnpj, String token) throws Exception {
    	
    	// https://iplocation.io/ip/187.44.228.230
    	LocalizacaoService.LocalizacaoCompleta info = LocalizacaoService.getLocalizacaoCompleta();

    	logger.info("IP: {}", info.ip);
    	logger.info("Cidade: {}", info.geo.city);
    	logger.info("CEP: {}", info.geo.zip);

    	// ==============================
    	// NORMALIZA CAMPOS (SEM NULL)
    	// ==============================

    	// GEO
    	String cidade = empty(info.geo.city);
    	String cep    = empty(info.geo.zip);
    	String pais   = empty(info.geo.country);
    	String regiao = empty(info.geo.region);
    	String lat    = empty(info.geo.lat);
    	String lon    = empty(info.geo.lon);

    	// ENDEREÇO
    	// String logradouro = empty(info.endereco.logradouro);
    	// String bairro     = empty(info.endereco.bairro);
    	// String uf         = empty(info.endereco.estado);

    	// logger.info("Logradouro: {}", logradouro);
    	// logger.info("Bairro: {}", bairro);
    	// logger.info("UF: {}", uf);

    	// Monta texto do e-mail
		String location = new StringBuilder()
		    .append("<div style=\"margin-top: 10px; line-height: 1.6;\">")
	
		    .append("<div><b>Localização da máquina no momento da geração do token:</b></div>")
		    .append("<div>A aplicação Java enviou automaticamente as seguintes informações:</div>")
		    .append("<br>")
	
		    .append("<div><b>IP Público:</b> ").append(info.ip).append("</div>")
		    .append("<div><b>País:</b> ").append(pais).append("</div>")
		    .append("<div><b>Região:</b> ").append(regiao).append("</div>")
		    .append("<div><b>Cidade:</b> ").append(cidade).append("</div>")
		    .append("<div><b>CEP:</b> ").append(cep).append("</div>")
		    .append("<div><b>Latitude:</b> ").append(lat).append("</div>")
		    .append("<div><b>Longitude:</b> ").append(lon).append("</div>")
	
		    .append("</div>")
		    .toString();
			//Logradouro: %s
			//Bairro: %s
			//UF: %s
    	
    	String dataHoraAtual = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")
    	        .withZone(ZoneId.systemDefault())
    	        .format(Instant.now());
    	
    	String saudacao;
    	LocalTime agora = LocalTime.now();

    	if (agora.isAfter(LocalTime.of(5, 0)) && agora.isBefore(LocalTime.of(12, 0))) {
    	    saudacao = "bom dia";
    	} else if (agora.isBefore(LocalTime.of(18, 0))) {
    	    saudacao = "boa tarde";
    	} else {
    	    saudacao = "boa noite";
    	}
    	
    	String empresa = contextService.getEmpresa();

		if (empresa == null || empresa.trim().isEmpty()) {
		    empresa = "Empresa Sem Contrato";
		}
		
		MaskFormatter mf = new MaskFormatter("##.###.###/####-##");
		mf.setValueContainsLiteralCharacters(false);
	    	
		String corpo = new StringBuilder()
			    .append("<html>")
			    .append("<body style=\"font-family: Arial, sans-serif; color: #333;\">")
			    .append("<p>Prezado, ").append(saudacao).append(".</p>")
			    .append("<p>Segue abaixo o token para a implantação do sistema contábil:</p>")

			    .append("<div style=\"margin-top: 10px; line-height: 1.6;\">")
			    .append("<div><b>Data/Hora:</b> ").append(dataHoraAtual).append("</div>")
			    .append("<div><b>CNPJ:</b> ").append(mf.valueToString(cnpj)).append("</div>")
			    .append("<div><b>Empresa:</b> ").append(empresa).append("</div>")
			    .append("<div><b>Token:</b> <span style=\"color: #0B5394; font-weight: bold;\">")
			    .append(token)
			    .append("</span></div>")
			    .append("</div>")
			    
			    .append("<div><b>Localização da máquina no momento da geração do token:</b> <span style=\"color: #0B5394; font-weight: bold;\">")
			    .append(location)
			    .append("</span></div>")
			    .append("</div>")

			    .append("<br>")
			    .append("<p>Att.,</p>")
			    .append("<p><b>Jean Venezia</b><br>")
			    .append("Diretor de TI</p>")
			    .append("</body>")
			    .append("</html>")
			    .toString();
		
        emailSender.sendEmail("jeanvenezia@gmail.com", "Token: " + mf.valueToString(cnpj) + " - " + empresa, corpo);
        //emailSender.sendEmail("helenocardosofilho@gmail.com", "Token - " + mf.valueToString(cnpj) + " - " + empresa, corpo);
    }
    
	// Função auxiliar
	private static String empty(String value) {
	    return (value == null || value.isBlank()) ? "(não disponível)" : value;
	}    

    public void restaurarTokensDoRegistro() {
    	if (isStorageEmpty()) {
    	    logger.warn("H2 está vazio. Restaurando tokens do Registro...");
    	    executionControl.restoreFromRegistry();
    	}
    	
    	//        executionControl.restoreFromRegistry();
    }
    
    public void atualizarJSONParaProducao() {
        try {
            TokenEnvioApiContabilidadeDTO envioDto = 
            		 new TokenEnvioApiContabilidadeDTO(contextService.getCnpj(), "", contextService.getCaminho());

            tokenService.postTokenContabilidade(envioDto);
            logger.info("Tokens atualizados com sucesso para produção.");
        } catch (Exception e) {
            logger.error("Falha ao atualizar tokens para produção: {}", e.getMessage()); //, e
        }
    }
}