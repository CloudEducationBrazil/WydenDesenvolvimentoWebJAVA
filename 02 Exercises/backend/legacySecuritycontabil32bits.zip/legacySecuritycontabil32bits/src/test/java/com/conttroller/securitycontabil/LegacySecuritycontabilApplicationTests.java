package com.conttroller.securitycontabil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LegacySecuritycontabilApplicationTests {

	@Test
	void contextLoads() {
	}

}
