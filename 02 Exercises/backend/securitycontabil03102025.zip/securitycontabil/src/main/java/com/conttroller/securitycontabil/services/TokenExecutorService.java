package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.dto.TokenEnvioApiContabilidadeDTO;
import com.conttroller.securitycontabil.dto.TokenRetornoApiContabilidadeDTO;
import com.conttroller.securitycontabil.entities.Token;
import com.conttroller.securitycontabil.execution.ExecutionControl;
import com.conttroller.securitycontabil.repositories.TokenRepository;

import jakarta.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;

@Service
public class TokenExecutorService {
    private static final Logger logger = LoggerFactory.getLogger(TokenExecutorService.class);

	private final TokenPersistenceService tokenPersistenceService;
    private final TokenService tokenService;
    private final EmailSender emailSender;
    private final AppContextService contextService;
    private final ExecutionControl executionControl;
    private final TokenRepository tokenRepository;
    
    public TokenExecutorService(TokenPersistenceService tokenPersistenceService,
                                TokenService tokenService,
                                EmailSender emailSender,
                                AppContextService contextService,
                                ExecutionControl executionControl,
                                TokenRepository tokenRepository) {
        this.tokenPersistenceService = tokenPersistenceService;
        this.tokenService = tokenService;
        this.emailSender = emailSender;
        this.contextService = contextService;
        this.executionControl = executionControl;
        this.tokenRepository = tokenRepository;
    }
    
    @PostConstruct
    public void restaurarSeNecessario() {
        if (isStorageEmpty()) {
            logger.warn("H2 está vazio na inicialização. Restaurando tokens do Registro...");

            long antes = tokenRepository.count();
            executionControl.restoreFromRegistry();
            long depois = tokenRepository.count();

            logger.info("[AUDITORIA] Tokens restaurados do Registro em {}. Total restaurado: {}",
                    java.time.LocalDateTime.now(),
                    (depois - antes));
        } else {
            logger.info("H2 já possui tokens. Nenhuma restauração necessária.");
        }
    }    

    /** Chamado pelo Scheduler */
    public void executarTokenReal() {
        salvarTokensTransacionado();
    }

    /** Transacional: salva/atualiza todos os tokens */
    @Transactional
    public void salvarTokensTransacionado() {
        List<Token> tokens = tokenService.carregarTokensParaExecutor();
        tokens.forEach(tokenPersistenceService::salvarOuAtualizar);
    }

    /** Gera token temporário para primeira execução */
    public String gerarToken() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    /** Envia token por e-mail */
    public void enviarTokenEmail(String cnpj, String token) throws Exception {
        String corpo = "Token para CNPJ: " + cnpj + " - Token: " + token;
        emailSender.sendEmail("helenocardosofilho@gmail.com", "Token", corpo);
    }

    /** Registra o serviço no Windows usando NSSM */
    public void executarRegistroService(String diretorToken) throws IOException, InterruptedException {
        String serviceName = "TokenService";
        String jarPath = contextService.getCaminho() + "\\securitycontabil.jar";

        // Detecta arquitetura do SO
        String osArch = System.getProperty("os.arch").contains("64") ? "nssm64.exe" : "nssm32.exe";

        // NSSM dentro do JAR, extrair para pasta temporária
        Path tempDir = Files.createTempDirectory("nssm");
        Path nssmExe = tempDir.resolve(osArch);

        try (InputStream is = getClass().getResourceAsStream("/nssm/" + osArch)) {
            Files.copy(is, nssmExe);
        }

        // Comando para instalar o serviço via NSSM
        String[] cmdInstall = {
                nssmExe.toString(),
                "install", serviceName,
                "java", "-jar", jarPath, diretorToken
        };

        ProcessBuilder pbInstall = new ProcessBuilder(cmdInstall);
        pbInstall.inheritIO();
        Process processInstall = pbInstall.start();
        int exitInstall = processInstall.waitFor();
        if (exitInstall == 0) {
        	logger.info("Serviço criado com sucesso via NSSM.");
        } else {
        	logger.error("Falha ao criar serviço. Código: " + exitInstall);
            return;
        }

        // Inicia o serviço
        String[] cmdStart = {nssmExe.toString(), "start", serviceName};
        ProcessBuilder pbStart = new ProcessBuilder(cmdStart);
        pbStart.inheritIO();
        Process processStart = pbStart.start();
        int exitStart = processStart.waitFor();
        if (exitStart == 0) {
        	logger.info("Serviço iniciado com sucesso via NSSM.");
        } else {
        	logger.error("Falha ao iniciar serviço. Código: " + exitStart);
        }
    }
    
    /**
     * Carrega o token oficial da API para atualizar H2 e registro do Windows.
     */
    public TokenRetornoApiContabilidadeDTO carregarTokenDaApi() {
        try {
            String cnpj = contextService.getCnpj();
            if (cnpj == null || cnpj.isBlank()) {
                logger.warn("CNPJ não definido. Não é possível carregar token da API.");
                return null;
            }

            // Monta o DTO para envio
            TokenEnvioApiContabilidadeDTO envioDto = new TokenEnvioApiContabilidadeDTO(cnpj, "", contextService.getCaminho());

            // Chama a API e retorna o DTO completo
            TokenRetornoApiContabilidadeDTO retornoDto = tokenService.postTokenContabilidade(envioDto);
            logger.info("Token oficial obtido da API com sucesso.");
            return retornoDto;

        } catch (Exception e) {
            logger.error("Falha ao obter token oficial da API: {}", e.getMessage(), e);
            return null;
        }
    }
    
    public void restaurarTokensDoRegistro() {
        executionControl.restoreFromRegistry();
    }
    
    public void atualizarJSONParaProducao() {
        try {
            TokenEnvioApiContabilidadeDTO envioDto = 
            		 new TokenEnvioApiContabilidadeDTO(contextService.getCnpj(), "", contextService.getCaminho());

            tokenService.postTokenContabilidade(envioDto);
            logger.info("Tokens atualizados com sucesso para produção.");
        } catch (Exception e) {
            logger.error("Falha ao atualizar tokens para produção: {}", e.getMessage(), e);
        }
    }
    
    public boolean isStorageEmpty() {
        return tokenRepository.count() == 0; // verifica se tabela H2 está vazia
    }   
}