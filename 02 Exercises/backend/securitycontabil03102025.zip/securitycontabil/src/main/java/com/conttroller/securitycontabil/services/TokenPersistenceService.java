package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.entities.Token;
import com.conttroller.securitycontabil.repositories.TokenRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TokenPersistenceService {

    private final TokenRepository tokenRepository;

    public TokenPersistenceService(TokenRepository tokenRepository) {
        this.tokenRepository = tokenRepository;
    }

    @Transactional
    public void salvarOuAtualizar(Token novoToken) {
        Optional<Token> optionalExistente = tokenRepository.findByCnpjAndSistemaForUpdate(
                novoToken.getCnpj(),
                novoToken.getSistema()
        );

        Token existente = optionalExistente.orElse(new Token());
        if (optionalExistente.isEmpty()) {
            existente.setCnpj(novoToken.getCnpj());
            existente.setSistema(novoToken.getSistema());
        }

        boolean mudou = false;
        if (!novoToken.getFinanceiro().equals(existente.getFinanceiro())) {
            existente.setFinanceiro(novoToken.getFinanceiro());
            mudou = true;
        }
        if (!novoToken.getHabilitado().equals(existente.getHabilitado())) {
            existente.setHabilitado(novoToken.getHabilitado());
            mudou = true;
        }
        if (!novoToken.getValidade().equals(existente.getValidade())) {
            existente.setValidade(novoToken.getValidade());
            mudou = true;
        }

        if (mudou || optionalExistente.isEmpty()) {
            tokenRepository.save(existente);
        }
    }

    public boolean isH2Vazio() {
        return tokenRepository.count() == 0;
    }

    public List<Token> listarTodos() {
        return tokenRepository.findAll();
    }
}