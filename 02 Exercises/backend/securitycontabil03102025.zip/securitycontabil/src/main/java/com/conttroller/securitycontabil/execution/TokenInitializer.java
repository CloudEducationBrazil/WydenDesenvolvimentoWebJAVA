package com.conttroller.securitycontabil.execution;

import com.conttroller.securitycontabil.services.TokenExecutorService;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
@org.springframework.context.annotation.Profile("!first") // só roda se o profile NÃO for "first"
public class TokenInitializer {

    private static final Logger logger = LoggerFactory.getLogger(TokenInitializer.class);

    private final TokenExecutorService tokenExecutorService;
    private boolean tokensCarregados = false;

    public TokenInitializer(TokenExecutorService tokenExecutorService) {
        this.tokenExecutorService = tokenExecutorService;
    }

    @EventListener(ApplicationReadyEvent.class)
    public synchronized void initTokens() {
        if (tokensCarregados) return;
        
        if (tokenExecutorService.isStorageEmpty()) { // <-- você precisaria criar esse método
            tokenExecutorService.restaurarTokensDoRegistro();
        }       

        try {
            logger.info("[TOKEN INIT] === Iniciando carregamento automático de tokens ===");

            ConexaoStatus status = verificarConexao();

            switch (status) {
                case ONLINE_OK -> {
                    logger.info("[TOKEN INIT][ONLINE_OK] Conexão detectada: buscando tokens na API...");
                    tokenExecutorService.executarTokenReal();
                }
                case ONLINE_ENDPOINT_INDISPONIVEL -> {
                    logger.warn("[TOKEN INIT][ENDPOINT_4XX] Conexão com internet ok, mas o endpoint está indisponível.");
                }
                case SEM_INTERNET -> {
                    logger.warn("[TOKEN INIT][NO_INTERNET] Sem conexão com a internet ou falha no servidor. Restaurando tokens do registro...");
                    tokenExecutorService.restaurarTokensDoRegistro();
                }
            }

            tokensCarregados = true;
            logger.info("[TOKEN INIT][OK] Tokens carregados e processados com sucesso.");
            //System.out.println("TokenService: inicialização concluída com sucesso. Verifique os logs para detalhes.");
        } catch (Exception e) {
            logger.error("[TOKEN INIT][FAIL] Falha ao carregar/processar tokens: {}", e.getMessage(), e);
            //System.out.println("TokenService: falha na inicialização. Consulte os logs para detalhes.");
        }
    }

    private enum ConexaoStatus {
        ONLINE_OK,
        ONLINE_ENDPOINT_INDISPONIVEL,
        SEM_INTERNET
    }

    private ConexaoStatus verificarConexao() {
        String url = "https://conttroller.net/api/d3";
        HttpClient client = HttpClient.newBuilder()
                                      .connectTimeout(Duration.ofSeconds(3))
                                      .build();

        HttpRequest request = HttpRequest.newBuilder()
                                         .uri(URI.create(url))
                                         .GET()
                                         .build();

        try {
            long start = System.currentTimeMillis();
            HttpResponse<Void> response = client.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                                                .orTimeout(3, java.util.concurrent.TimeUnit.SECONDS)
                                                .join();

            long duration = System.currentTimeMillis() - start;
            int status = response.statusCode();

            if (status == 200) {
                logger.info("[TOKEN INIT][ONLINE_OK] Ping bem-sucedido para {} ({} ms)", url, duration);
                return ConexaoStatus.ONLINE_OK;
            } else if (status >= 500) {
                logger.warn("[TOKEN INIT][NO_INTERNET] Ping falhou com status {} (erro de servidor remoto, {} ms).", status, duration);
                return ConexaoStatus.SEM_INTERNET;
            } else {
                logger.warn("[TOKEN INIT][ENDPOINT_4XX] Ping retornou status {} ({} ms). Conexão existe, mas recurso não disponível.", status, duration);
                return ConexaoStatus.ONLINE_ENDPOINT_INDISPONIVEL;
            }

        } catch (Exception e) {
            logger.warn("[TOKEN INIT][NO_INTERNET] Falha ao testar conexão com {}: {}", url, e.getMessage());
            return ConexaoStatus.SEM_INTERNET;
        }
    }
}