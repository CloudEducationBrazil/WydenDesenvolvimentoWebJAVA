package com.conttroller.securitycontabil.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class TokenScheduler {
    @Autowired
    private TokenExecutorService tokenExecutorService;

    // Executa a cada 3 horas (10,800,000 ms)
    // Executa a cada 2 min (120,000 ms)
    @Scheduled(fixedRate = 120000) // 10800000
    public void executarConsulta() {
    	tokenExecutorService.executarToken(); // chama o mesmo método
    } 	
}