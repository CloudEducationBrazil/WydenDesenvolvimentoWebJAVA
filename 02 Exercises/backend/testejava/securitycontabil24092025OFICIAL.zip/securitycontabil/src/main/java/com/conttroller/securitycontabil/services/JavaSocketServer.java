package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.entities.Token;
import com.conttroller.securitycontabil.repositories.TokenRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Optional;

@Service
public class JavaSocketServer {

    private ServerSocket serverSocket;
    private final int porta = 8587;
    private final TokenRepository tokenRepository;

    public JavaSocketServer(TokenRepository tokenRepository) {
        this.tokenRepository = tokenRepository;
    }
    
    @Autowired
    private AppContextService appContextService;    

    @PostConstruct
    public void startServer() {
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(porta);
                System.out.println("Socket rodando na porta " + porta);

                while (!serverSocket.isClosed()) {
                    try (
                        Socket clientSocket = serverSocket.accept();
                        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
                    ) {
                        String command = in.readLine();
                        System.out.println("Comando recebido: " + command);

                        switch (command.toUpperCase()) {
                            case "GET_FISCAL":
                                enviarToken("FISCAL", out);
                                break;
                            case "GET_CONTABIL":
                                enviarToken("CONTABIL", out);
                                break;
                            case "GET_FOLHA":
                                enviarToken("FOLHA", out);
                                break;
                            default:
                                out.println("COMANDO DESCONHECIDO");
                        }

                        out.println("END"); // marca fim da resposta

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            } catch (IOException e) {
                System.err.println("Não foi possível abrir a porta " + porta + ": " + e.getMessage());
            }
        }).start();
    }

    @PreDestroy
    public void stopServer() {
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
                System.out.println("Socket fechado.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void enviarToken(String sistema, PrintWriter out) {
        Optional<Token> tokenOpt = tokenRepository.findBySistemaAndCnpj(sistema, appContextService.getCnpj()); // se quiser filtrar por CNPJ, coloque aqui
        tokenOpt.ifPresentOrElse(
            t -> out.println(t.getSistema() + ";" + t.getValidade() + ";" + t.getHabilitado() + ";" + t.getFinanceiro()),
            () -> out.println("TOKEN NÃO ENCONTRADO")
        );
    }
}