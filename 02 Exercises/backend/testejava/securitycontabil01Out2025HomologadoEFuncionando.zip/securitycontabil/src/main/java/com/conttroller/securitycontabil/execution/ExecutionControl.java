package com.conttroller.securitycontabil.execution;

import com.conttroller.securitycontabil.dto.TokenRetornoApiContabilidadeDTO;
import com.conttroller.securitycontabil.services.TokenService;
import com.conttroller.securitycontabil.storage.TokenStorage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Optional;

@Component
public class ExecutionControl {

    private static final Logger logger = LoggerFactory.getLogger(ExecutionControl.class);
    private static final String TOKEN_KEY = "nekot";

    private final TokenStorage tokenStorage;
    private final TokenService tokenService;  // para gravar no H2
    
    public ExecutionControl(TokenStorage tokenStorage, TokenService tokenService) {
        this.tokenStorage = tokenStorage;
        this.tokenService = tokenService;
    }

    /** Retorna true se for a primeira execução (token ainda não existe) */
    public boolean isFirstRun() {
        try {
            Optional<String> stored = tokenStorage.load(TOKEN_KEY);
            return stored.isEmpty();
        } catch (IOException e) {
            logger.error("Erro ao verificar token no registro: {}", e.getMessage(), e);
            return true; // assume primeira execução em caso de erro
        }
    }

    /** Grava o token no registro do Windows */
    public void saveToken(String token) {
        try {
            tokenStorage.save(TOKEN_KEY, token);
        } catch (IOException e) {
            logger.error("Erro ao salvar token no registro: {}", e.getMessage(), e);
        }
    }

    /** Lê o token armazenado */
    public String getStoredToken() {
        try {
            return tokenStorage.load(TOKEN_KEY).orElse(null);
        } catch (IOException e) {
            logger.error("Erro ao ler token do registro: {}", e.getMessage(), e);
            return null;
        }
    }

    /** Atualiza o token no H2 e no registro */
    public void updateTokenFromApi(String cnpj, TokenRetornoApiContabilidadeDTO apiResponse) {
        try {
            // Grava no H2
            String token = apiResponse.getAssinatura();
            tokenService.salvarOuAtualizarToken(cnpj, token);
            saveToken(token); // grava no registro do Windows            logger.info("Token atualizado no H2 e no registro do Windows com sucesso.");
        } catch (Exception e) {
            logger.error("Falha ao atualizar token: {}", e.getMessage(), e);
        }
    }
}