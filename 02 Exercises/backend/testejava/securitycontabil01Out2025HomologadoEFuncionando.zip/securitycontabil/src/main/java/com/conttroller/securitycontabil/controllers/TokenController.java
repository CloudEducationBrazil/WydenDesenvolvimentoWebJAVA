package com.conttroller.securitycontabil.controllers;

import org.springframework.web.bind.annotation.*;

import com.conttroller.securitycontabil.dto.TokenEnvioApiContabilidadeDTO;
import com.conttroller.securitycontabil.dto.TokenRetornoApiContabilidadeDTO;
import com.conttroller.securitycontabil.services.TokenService;

import java.io.File;

@RestController
@RequestMapping("/api/tokencontabilidade")
public class TokenController {

    private final TokenService tokenService;

    public TokenController(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    @PostMapping
    public TokenRetornoApiContabilidadeDTO postTokenContabilidade(
            @RequestBody(required = false) TokenEnvioApiContabilidadeDTO body) throws Exception {

        // Se body não for enviado, usamos valores padrão
        if (body == null) {
            body = new TokenEnvioApiContabilidadeDTO(
                    "00000000000199",  // CNPJ padrão
                    "",                 // Senha padrão (será preenchida no TokenService)
                    new File("C:\\conttrol\\") // Caminho padrão
            );
        }

        // Delegamos a chamada ao TokenService
        return tokenService.postTokenContabilidade(body);
    }
}