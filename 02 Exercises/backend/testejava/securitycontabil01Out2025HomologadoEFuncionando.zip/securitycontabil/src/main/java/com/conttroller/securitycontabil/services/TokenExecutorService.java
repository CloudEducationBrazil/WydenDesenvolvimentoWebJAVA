package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.dto.TokenEnvioApiContabilidadeDTO;
import com.conttroller.securitycontabil.dto.TokenRetornoApiContabilidadeDTO;
import com.conttroller.securitycontabil.entities.Token;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;

@Service
public class TokenExecutorService {
    private static final Logger logger = LoggerFactory.getLogger(AppExecutionService.class);

	@Value("${caminho.default}")
	String caminho;

	private final TokenPersistenceService tokenPersistenceService;
    private final TokenService tokenService;
    private final EmailSender emailSender;
    private final AppContextService contextService;

    public TokenExecutorService(TokenPersistenceService tokenPersistenceService,
                                TokenService tokenService,
                                EmailSender emailSender,
                                AppContextService contextService) {
        this.tokenPersistenceService = tokenPersistenceService;
        this.tokenService = tokenService;
        this.emailSender = emailSender;
        this.contextService = contextService;
    }

    /** Chamado pelo Scheduler */
    public void executarTokenReal() {
        salvarTokensTransacionado();
    }

    /** Transacional: salva/atualiza todos os tokens */
    @Transactional
    public void salvarTokensTransacionado() {
        List<Token> tokens = tokenService.carregarTokensParaExecutor();
        tokens.forEach(tokenPersistenceService::salvarOuAtualizar);
    }

    /** Gera token temporário para primeira execução */
    public String gerarToken() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    /** Envia token por e-mail */
    public void enviarTokenEmail(String cnpj, String token) throws Exception {
        String corpo = "Token para CNPJ: " + cnpj + " - Token: " + token;
        emailSender.sendEmail("helenocardosofilho@gmail.com", "Token", corpo);
    }

    /** Registra o serviço no Windows usando NSSM */
    public void executarRegistroService(String diretorToken) throws IOException, InterruptedException {
        String serviceName = "TokenService";
        String jarPath = caminho + "\\securitycontabil.jar";

        // Detecta arquitetura do SO
        String osArch = System.getProperty("os.arch").contains("64") ? "nssm64.exe" : "nssm32.exe";

        // NSSM dentro do JAR, extrair para pasta temporária
        Path tempDir = Files.createTempDirectory("nssm");
        Path nssmExe = tempDir.resolve(osArch);

        try (InputStream is = getClass().getResourceAsStream("/nssm/" + osArch)) {
            Files.copy(is, nssmExe);
        }

        // Comando para instalar o serviço via NSSM
        String[] cmdInstall = {
                nssmExe.toString(),
                "install", serviceName,
                "java", "-jar", jarPath, diretorToken
        };

        ProcessBuilder pbInstall = new ProcessBuilder(cmdInstall);
        pbInstall.inheritIO();
        Process processInstall = pbInstall.start();
        int exitInstall = processInstall.waitFor();
        if (exitInstall == 0) {
            System.out.println("Serviço criado com sucesso via NSSM.");
        } else {
            System.err.println("Falha ao criar serviço. Código: " + exitInstall);
            return;
        }

        // Inicia o serviço
        String[] cmdStart = {nssmExe.toString(), "start", serviceName};
        ProcessBuilder pbStart = new ProcessBuilder(cmdStart);
        pbStart.inheritIO();
        Process processStart = pbStart.start();
        int exitStart = processStart.waitFor();
        if (exitStart == 0) {
            System.out.println("Serviço iniciado com sucesso via NSSM.");
        } else {
            System.err.println("Falha ao iniciar serviço. Código: " + exitStart);
        }
    }
    
    /**
     * Carrega o token oficial da API para atualizar H2 e registro do Windows.
     */
    public TokenRetornoApiContabilidadeDTO carregarTokenDaApi() {
        try {
            String cnpj = contextService.getCnpj();
            if (cnpj == null || cnpj.isBlank()) {
                logger.warn("CNPJ não definido. Não é possível carregar token da API.");
                return null;
            }

            // Monta o DTO para envio
            TokenEnvioApiContabilidadeDTO envioDto = new TokenEnvioApiContabilidadeDTO(cnpj, "", contextService.getCaminho());

            // Chama a API e retorna o DTO completo
            TokenRetornoApiContabilidadeDTO retornoDto = tokenService.postTokenContabilidade(envioDto);
            logger.info("Token oficial obtido da API com sucesso.");
            return retornoDto;

        } catch (Exception e) {
            logger.error("Falha ao obter token oficial da API: {}", e.getMessage(), e);
            return null;
        }
    }
}