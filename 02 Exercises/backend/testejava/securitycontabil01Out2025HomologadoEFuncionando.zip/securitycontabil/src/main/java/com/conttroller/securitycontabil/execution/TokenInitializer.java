package com.conttroller.securitycontabil.execution;

import com.conttroller.securitycontabil.services.TokenExecutorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class TokenInitializer {

    private static final Logger logger = LoggerFactory.getLogger(TokenInitializer.class);

    private final TokenExecutorService tokenExecutorService;
    private boolean tokensCarregados = false;

    public TokenInitializer(TokenExecutorService tokenExecutorService) {
        this.tokenExecutorService = tokenExecutorService;
    }

    /**
     * Inicializa os tokens automaticamente após a aplicação estar pronta.
     * Garante que seja executado apenas uma vez.
     */
    @EventListener(ApplicationReadyEvent.class)
    public synchronized void initTokens() {
        if (tokensCarregados) return;

        try {
            logger.info("=== Iniciando carregamento automático de tokens ===");

            // Chama executor para carregar e salvar tokens
            tokenExecutorService.executarTokenReal();

            tokensCarregados = true;
            logger.info("=== Tokens carregados e processados com sucesso ===");
        } catch (Exception e) {
            logger.error("Falha ao carregar/processar tokens na inicialização: {}", e.getMessage(), e);
        }
    }
}