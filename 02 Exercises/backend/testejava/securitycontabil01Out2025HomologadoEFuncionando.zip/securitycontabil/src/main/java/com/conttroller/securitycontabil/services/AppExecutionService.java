package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.components.ApplicationContextProvider;
import com.conttroller.securitycontabil.execution.ExecutionControl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;

@Service
public class AppExecutionService {

    private static final Logger logger = LoggerFactory.getLogger(AppExecutionService.class);

    private final ExecutionControl executionControl;
    private final TokenExecutorService tokenExecutorService;
    private final AppContextService contextService;
    private final ApplicationContextProvider contextProvider;

    public AppExecutionService(
            ExecutionControl executionControl,
            TokenExecutorService tokenExecutorService,
            AppContextService contextService,
            ApplicationContextProvider contextProvider) {
        this.executionControl = executionControl;
        this.tokenExecutorService = tokenExecutorService;
        this.contextService = contextService;
        this.contextProvider = contextProvider;
    }

    /** Fluxo principal */
    public void executar(String cnpj, String caminhoStr, String tokenFornecido) {
        try {
            File caminho = new File(caminhoStr);
            if (!caminho.exists() && !caminho.mkdirs()) {
                logger.warn("Não foi possível criar o diretório: {}", caminho.getAbsolutePath());
            }

            contextService.setCnpj(cnpj);
            contextService.setCaminho(caminho);

            if (executionControl.isFirstRun()) {
                executarPrimeiraExecucao();
            } else if (tokenFornecido != null && !tokenFornecido.isBlank()) {
            	
            	String storedToken = executionControl.getStoredToken();
                if (!storedToken.equals(tokenFornecido)) {
                    System.err.println("Token informado não corresponde ao token registrado! Abortando execução.");
                    System.exit(1);
                }
            	            	
                validarERegistrarServico(tokenFornecido);
            } else {
                logger.info("Execução normal: nenhuma ação de registro requerida.");
            }
        } catch (Exception e) {
            logger.error("Erro durante a execução: {}", e.getMessage(), e);
            contextProvider.exitApplication(1);
        }
    }

    private void executarPrimeiraExecucao() {
        try {
            logger.info("=== Primeira execução ===");
            String tokenTemp = tokenExecutorService.gerarToken();
            executionControl.saveToken(tokenTemp);
            tokenExecutorService.executarTokenReal();
            tokenExecutorService.enviarTokenEmail(contextService.getCnpj(), tokenTemp);
            logger.info("Token enviado. Aplicação encerrada.");
            contextProvider.exitApplication(0);
        } catch (Exception e) {
            logger.error("Erro na primeira execução: {}", e.getMessage(), e);
            contextProvider.exitApplication(1);
        }
    }

    private void validarERegistrarServico(String tokenFornecido) {
        try {
            contextService.setInputToken(tokenFornecido);
            String tokenArmazenado = executionControl.getStoredToken();
            if (!tokenFornecido.equals(tokenArmazenado)) {
                throw new SecurityException("Token inválido.");
            }
            tokenExecutorService.executarRegistroService(tokenArmazenado);
            logger.info("Serviço registrado com sucesso.");
        } catch (Exception e) {
            logger.error("Falha ao validar token ou registrar serviço: {}", e.getMessage(), e);
            contextProvider.exitApplication(1);
        }
    }
}