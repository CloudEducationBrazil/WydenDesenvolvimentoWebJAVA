package com.conttroller.securitycontabil;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.conttroller.securitycontabil.services.AppExecutionService;

@SpringBootApplication
@EnableAsync
@EnableFeignClients(basePackages = "com.conttroller.securitycontabil.interfaces")
@EnableScheduling
public class SecuritycontabilApplication implements CommandLineRunner {

    private final AppExecutionService appExecutionService;

    @Value("${cnpj.default:}")
    private String defaultCnpj;

    @Value("${caminho.default:}")
    private String defaultCaminho;

    public SecuritycontabilApplication(AppExecutionService appExecutionService) {
        this.appExecutionService = appExecutionService;
    }

    public static void main(String[] args) {
        SpringApplication.run(SecuritycontabilApplication.class, args);
    }

    @Override
    public void run(String... args) {
        //if (args.length < 2) {
       //     throw new IllegalArgumentException( 
       //         "Uso: java -jar app.jar <CNPJ> <Caminho> [<Token>]"
       //     );
     //   }

        //String cnpj = !args[0].isBlank() ? args[0] : defaultCnpj;
        //String caminho = !args[1].isBlank() ? args[1] : defaultCaminho;
        //String token = args.length >= 3 ? args[2] : null;
        
        String cnpj = (args.length > 0 && !args[0].isBlank()) ? args[0] : defaultCnpj;
        String caminho = (args.length > 1 && !args[1].isBlank()) ? args[1] : defaultCaminho;
        String token = (args.length > 2) ? args[2] : null;        
        
        System.out.println("GMAIL_APP_PASSWORD = " + System.getenv("GMAIL_APP_PASSWORD"));

        appExecutionService.executar(cnpj, caminho, token);
    }
}