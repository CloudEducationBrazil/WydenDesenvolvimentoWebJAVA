package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.dto.*;
import com.conttroller.securitycontabil.entities.Token;
import com.conttroller.securitycontabil.interfaces.TokenClient;
import com.conttroller.securitycontabil.repositories.TokenRepository;
import com.conttroller.securitycontabil.storage.TokenStorage;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.*;

@Service
public class TokenService {

    private static final Logger logger = LoggerFactory.getLogger(TokenService.class);
   // private static final String PASSWORD_DEFAULT = "lorttnocToken2025@";

    private final TokenClient tokenClient;
    private final TokenRepository tokenRepository;
    private final ObjectMapper objectMapper;
    private final AppContextService appContextService;
    private final TokenStorage tokenStorage;

    public TokenService(TokenClient tokenClient,
                        TokenRepository tokenRepository,
                        ObjectMapper objectMapper,
                        AppContextService appContextService,
                        TokenStorage tokenStorage) {
        this.tokenClient = tokenClient;
        this.tokenRepository = tokenRepository;
        this.objectMapper = objectMapper;
        this.appContextService = appContextService;
        this.tokenStorage = tokenStorage;
    }

    /** Retorna lista de tokens para Executor */
    @Transactional
    public List<Token> carregarTokensParaExecutor() {
        String cnpj = appContextService.getCnpj();
        File pastaTokens = appContextService.getCaminho();
        boolean h2Vazio = tokenRepository.count() == 0;

        List<Token> listaTokens = new ArrayList<>();

        try {
            if (cnpj != null && pastaTokens != null) {
                // Chama a API e salva H2
                TokenEnvioApiContabilidadeDTO envioDto = new TokenEnvioApiContabilidadeDTO(cnpj, "", pastaTokens);
                TokenRetornoApiContabilidadeDTO retornoDto = tokenClient.postToken(envioDto);

                salvarTokensH2(retornoDto);

                listaTokens = tokenRepository.findAll();
            } else if (h2Vazio) {
                // Carrega do storage se H2 estiver vazio
                carregarTokensDoStorage();
                listaTokens = tokenRepository.findAll();
            } else {
                // Tokens já existem
                listaTokens = tokenRepository.findAll();
            }
        } catch (Exception e) {
            logger.error("Erro ao carregar tokens para executor: {}", e.getMessage(), e);
        }

        return listaTokens;
    }
    
 //   private final Object lock = new Object();

    @Transactional
    public void salvarTokensH2(TokenRetornoApiContabilidadeDTO dto) {
        if (dto.getServidor() == null || dto.getServidor().getSistemas() == null) return;

        dto.getServidor().getSistemas().forEach(sistema -> {
            if (sistema.getModulos() != null && !sistema.getModulos().isEmpty()) {
                var settings = sistema.getModulos().get(0).getSettings();
                if (settings != null) {
                    String cnpj = dto.getCnpj().trim();
                    String nomeSistema = sistema.getSistema().trim();
                    String habilitado = settings.getHabilitado();
                    String financeiro = settings.getStatusFin();
                    OffsetDateTime validade = dto.getValidade();

                    try {
                        tokenRepository.mergeToken(cnpj, nomeSistema, habilitado, financeiro, validade);
                        logger.info("Token salvo/atualizado via MERGE: {} - {}", cnpj, nomeSistema);
                    } catch (Exception e) {
                        logger.error("Erro ao salvar token via MERGE: {} - {}", cnpj, nomeSistema, e);
                    }
                }
            }
        });
    }
    
    private void carregarTokensDoStorage() throws IOException {
        Optional<String> jsonOriginal = tokenStorage.load("TokenOriginal");
        if (jsonOriginal.isPresent()) {
            TokenRetornoApiContabilidadeDTO originalDto =
                    objectMapper.readValue(jsonOriginal.get(), TokenRetornoApiContabilidadeDTO.class);
            salvarTokensH2(originalDto);
            logger.info("Tokens carregados do storage com sucesso.");
        } else {
            logger.warn("Nenhum token encontrado no storage.");
        }
    }

    private void salvarTokensEmDisco(TokenRetornoApiContabilidadeDTO dto, File pastaTokens) throws IOException {
        pastaTokens.mkdirs();
        String jsonOriginal = objectMapper.writeValueAsString(dto);
        String jsonReduzido = objectMapper.writeValueAsString(mapearParaMinDTO(dto));

        try (FileWriter fwO = new FileWriter(new File(pastaTokens, "token_contabilidade_ori.json"));
             FileWriter fwR = new FileWriter(new File(pastaTokens, "token_contabilidade_red.json"))) {
            fwO.write(jsonOriginal);
            fwR.write(jsonReduzido);
        }
        logger.info("Tokens salvos em disco em {}", pastaTokens.getAbsolutePath());
    }

    private TokenRetornoApiContabilidadeMinDTO mapearParaMinDTO(TokenRetornoApiContabilidadeDTO dtoCompleto) {
        TokenRetornoApiContabilidadeMinDTO dtoMin = new TokenRetornoApiContabilidadeMinDTO();
        dtoMin.setId(dtoCompleto.getId());
        dtoMin.setCnpj(dtoCompleto.getCnpj());
        dtoMin.setValidade(dtoCompleto.getValidade());
        dtoMin.setAssinatura(dtoCompleto.getAssinatura());

        if (dtoCompleto.getServidor() != null && dtoCompleto.getServidor().getSistemas() != null) {
            dtoCompleto.getServidor().getSistemas().forEach(sistema -> {
                if (sistema.getModulos() != null && !sistema.getModulos().isEmpty()) {
                    var settings = sistema.getModulos().get(0).getSettings();
                    if (settings != null) {
                        TokenRetornoApiContabilidadeMinDTO.SistemaDTO sistemaMin = new TokenRetornoApiContabilidadeMinDTO.SistemaDTO();
                        sistemaMin.setHabilitado(settings.getHabilitado());
                        sistemaMin.setStatusFin(settings.getStatusFin());
                        switch (sistema.getSistema().toUpperCase()) {
                            case "FISCAL" -> dtoMin.setFiscal(sistemaMin);
                            case "CONTABIL" -> dtoMin.setContabil(sistemaMin);
                            case "FOLHA" -> dtoMin.setFolha(sistemaMin);
                        }
                    }
                }
            });
        }
        return dtoMin;
    }
    
    public TokenRetornoApiContabilidadeDTO postTokenContabilidade(TokenEnvioApiContabilidadeDTO body) throws Exception {
        // Chama a API e obtém os tokens
        TokenRetornoApiContabilidadeDTO retornoDto = tokenClient.postToken(body);

        File pastaTokens = body.getCaminho();

        // Salvar os tokens em disco
        salvarTokensEmDisco(retornoDto, pastaTokens);

        // Salvar no storage
        tokenStorage.save("TokenOriginal", objectMapper.writeValueAsString(retornoDto));
        TokenRetornoApiContabilidadeMinDTO minDto = mapearParaMinDTO(retornoDto);
        tokenStorage.save("TokenReduzido", objectMapper.writeValueAsString(minDto));

        // Salvar ou atualizar tokens no H2 (upsert seguro)
        salvarTokensH2(retornoDto);

        return retornoDto;
    }

    @Transactional
    public void salvarOuAtualizarToken(String cnpj, String tokenApi) {
        try {
            if (cnpj == null || cnpj.isBlank() || tokenApi == null || tokenApi.isBlank()) {
                logger.warn("CNPJ ou token vazio. Abortando atualização.");
                return;
            }

            // Atualiza cada sistema existente ou cria novo no H2
            List<String> sistemas = List.of("FISCAL", "CONTABIL", "FOLHA"); // exemplo de sistemas
            OffsetDateTime validade = OffsetDateTime.now().plusYears(1); // validade genérica, pode vir do API se disponível

            for (String sistema : sistemas) {
                try {
                    tokenRepository.mergeToken(
                            cnpj,
                            sistema,
                            "S",        // habilitado
                            "N",        // financeiro (ou outro valor)
                            validade
                    );
                    logger.info("Token atualizado via MERGE no H2: {} - {}", cnpj, sistema);
                } catch (Exception e) {
                    logger.error("Erro ao atualizar token via MERGE: {} - {}", cnpj, sistema, e);
                }
            }
        } catch (Exception e) {
            logger.error("Falha ao salvar ou atualizar token: {}", e.getMessage(), e);
        }
    }    
}