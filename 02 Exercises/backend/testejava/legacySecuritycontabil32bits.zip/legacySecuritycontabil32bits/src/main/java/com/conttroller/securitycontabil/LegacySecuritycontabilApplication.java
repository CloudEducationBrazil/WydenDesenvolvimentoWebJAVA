package com.conttroller.securitycontabil;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.conttroller.securitycontabil.services.AppContextService;
import com.conttroller.securitycontabil.services.AppExecutionService;
import com.conttroller.securitycontabil.utils.RegistroUtils;

@SpringBootApplication
@EnableAsync
@EnableFeignClients(basePackages = "com.conttroller.securitycontabil.interfaces")
@EnableScheduling
public class LegacySecuritycontabilApplication implements CommandLineRunner {
    private static final Logger logger = LoggerFactory.getLogger(LegacySecuritycontabilApplication.class);
	
    private final AppExecutionService appExecutionService;
	private final RegistroUtils registroUtils;
    private final AppContextService contextService;

    @Value("${cnpj.default:}")
    private String defaultCnpj;

    @Value("${caminho.default:}")
    private String defaultCaminho;

	public LegacySecuritycontabilApplication(AppExecutionService appExecutionService, RegistroUtils registroUtils, AppContextService contextService) {
	    this.appExecutionService = appExecutionService;
	    this.registroUtils = registroUtils;
	    this.contextService = contextService;
	}	

    public static void main(String[] args) {
        SpringApplication.run(LegacySecuritycontabilApplication.class, args);
    }

    @Override
    public void run(String... args) {
        /*if (args.length < 2) {
            throw new IllegalArgumentException( 
                "Uso: java -jar app.jar <CNPJ> <Caminho> [<Token>]"
            );
        } */
 
        String cnpj = (args.length > 0 && !args[0].isBlank()) ? args[0] : defaultCnpj;
        String caminho = (args.length > 1 && !args[1].isBlank()) ? args[1] : defaultCaminho;
        String token = (args.length > 2) ? args[2] : null;

        // Verifica se o token já existe no registro do Windows antes de continuar
	    if (args.length == 3) {
	        // Exige que o token exista
	        if (!registroUtils.verificarTokenExistente()) {
	            String msg = "Token não encontrado. Execute a primeira instalação antes de Registrar o Serviço.";
	            logger.error(msg);
	            System.err.println(msg);
	            System.exit(1);
	        }
	    }
	    
	    contextService.setCnpj(cnpj);
	    contextService.setCaminho(new File(caminho));
	    contextService.setInputToken(token);

        appExecutionService.executar();
    }
}