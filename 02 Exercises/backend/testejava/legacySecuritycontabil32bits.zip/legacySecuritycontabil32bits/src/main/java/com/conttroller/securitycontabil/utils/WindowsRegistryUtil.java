package com.conttroller.securitycontabil.utils;

import com.sun.jna.platform.win32.Advapi32Util;
import com.sun.jna.platform.win32.WinReg;

public class WindowsRegistryUtil {

    public static void writeString(String key, String name, String value) {
        Advapi32Util.registryCreateKey(WinReg.HKEY_CURRENT_USER, key);
        Advapi32Util.registrySetStringValue(WinReg.HKEY_CURRENT_USER, key, name, value);
    }

    public static String readString(String key, String name) {
        if (Advapi32Util.registryKeyExists(WinReg.HKEY_CURRENT_USER, key)) {
            return Advapi32Util.registryGetStringValue(WinReg.HKEY_CURRENT_USER, key, name);
        }
        return null;
    }
}