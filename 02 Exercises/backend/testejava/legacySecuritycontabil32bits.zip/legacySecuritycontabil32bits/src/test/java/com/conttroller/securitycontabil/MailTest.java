package com.conttroller.securitycontabil;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

@SpringBootTest //(properties = "spring.profiles.active=test")
public class MailTest {
    @Autowired
    private JavaMailSender mailSender;

    @Test
    void sendTestMail() {
    	try 
    	{
	        SimpleMailMessage message = new SimpleMailMessage();
	        message.setFrom("helenocardosofilho@gmail.com"); // remetente obrigatório no Gmail
	        message.setTo("helenocardosofilho@gmail.com");   // pode ser o mesmo para teste
	        
	        message.setSubject("Teste SMTP");
	        message.setText("Mensagem de teste via Spring Boot.");
	        
	        mailSender.send(message);
	        
	        //System.out.println("Senha APP lida: " + System.getenv("GMAIL_APP_PASSWORD"));
	        System.out.println("✅ E-mail enviado com sucesso!");
    	}
    	catch (Exception e) {
	        System.out.println("[APP EXECUTION][FIRST_RUN][FAIL] Erro na primeira execução!");
    	}
	}
}