package com.conttroller.tokencontabilidade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TokencontabilidadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
