package com.conttroller.tokencontabilidade.enums;

public enum StatusToken {
    ATIVO,
    INATIVO,
    EXPIRADO,
    PENDENTE;
}
