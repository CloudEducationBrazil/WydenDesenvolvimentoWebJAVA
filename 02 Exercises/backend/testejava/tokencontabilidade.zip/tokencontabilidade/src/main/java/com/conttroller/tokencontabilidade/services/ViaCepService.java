package com.conttroller.tokencontabilidade.services;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;

@Service
public class ViaCepService {

	private static final String URL_VIACEP = "https://viacep.com.br/ws/%s/json/";

    private final WebClient webClient;

    // http://localhost:8585/consultarCep/{CEP}
    // http://localhost:8585/consultarCep/41720075
    public ViaCepService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("https://viacep.com.br/ws").build();
    }
    
//	<configuration>
//	<propertiesEncoding>UTF-8</propertiesEncoding> <!-- Este
//	parâmetro será reconhecido na versão mais recente -->
//</configuration>

    public JsonNode consultarCep(String cep) {
        // Faz a requisição assíncrona e espera a resposta
    	//System.out.print("CEP: " + String.format(URL_VIACEP, cep) + "  ");

        return webClient.get()
                        .uri(String.format(URL_VIACEP, cep))
                        .retrieve()
                        .bodyToMono(JsonNode.class)
                        .block();  // Usado para bloquear a resposta de forma síncrona (não recomendado em produção reativa)
    }
}