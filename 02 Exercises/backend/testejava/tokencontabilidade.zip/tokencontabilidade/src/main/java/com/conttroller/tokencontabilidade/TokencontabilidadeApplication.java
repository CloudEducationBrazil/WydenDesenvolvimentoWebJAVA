package com.conttroller.tokencontabilidade;

import org.springframework.boot.CommandLineRunner;

import java.io.File;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.scheduling.annotation.EnableScheduling;

import com.conttroller.tokencontabilidade.config.TokenConfig;
import com.conttroller.tokencontabilidade.dto.TokenJsonDTO;
import com.conttroller.tokencontabilidade.enums.StatusToken;
import com.conttroller.tokencontabilidade.services.TokenService;
import com.conttroller.tokencontabilidade.services.ViaCepService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication
//@EnableScheduling
public class TokencontabilidadeApplication implements CommandLineRunner {
	private final ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
    private TokenService tokenService;

	@Autowired
    private ViaCepService viaCepService;
	
    @Autowired
    private TokenConfig tokenConfig;

	public static void main(String[] args) {
        SpringApplication app = new SpringApplication(TokencontabilidadeApplication.class);
        app.setWebApplicationType(WebApplicationType.NONE); // não iniciar servidor Web
        app.run(args);
		//SpringApplication.run(TokencontabilidadeApplication.class, args);
 	}
	
    @Override
    public void run(String... args) throws Exception, IOException, IllegalArgumentException {
    	try {
	        // Carregar token.json
    		String caminhoArquivoJSON = tokenConfig.getCaminhoArquivoJSON(); //"D:\\testejava\\token.json";
	        
	        // Verifica se a variável está definida
	        if (caminhoArquivoJSON == null || caminhoArquivoJSON.isEmpty()) {
	        	caminhoArquivoJSON = System.getenv("caminhoArquivoJSON");
		        if (caminhoArquivoJSON == null || caminhoArquivoJSON.isEmpty()) {
	              throw new IllegalArgumentException("Variável de ambiente 'caminhoArquivoJSON' não está definida.");
		        }  
	        }
	        
	        tokenService.carregarJSON(caminhoArquivoJSON);
	        
            File arquivo = new File(caminhoArquivoJSON);

            mapper.findAndRegisterModules(); // Necessário para LocalDate
            TokenJsonDTO dto = mapper.readValue(arquivo, TokenJsonDTO.class);            
  
            System.out.println(dto.toString());
            //System.out.println("Id : " + dto.getId());
            //System.out.println("Sistema: " + dto.getSistema());
 	        
	        String cep = dto.getId(); //"41720075";
	        
	        JsonNode jsonNode = viaCepService.consultarCep(cep);
	        System.out.println(jsonNode);
	        
	        //String local = jsonNode.get("localidade").asText();
	        //StatusToken statusToken = StatusToken.ATIVO;
	        StatusToken statusToken =  StatusToken.valueOf("ATIVO");
	        
	        // Atualizar STATUS no token.json 
	        tokenService.atualizarStatus(arquivo, statusToken);
	        
	        System.out.println("JSON atualizado com sucesso.");
    	 } catch (Exception e) {
    	      e.printStackTrace(); // Exibe o erro no log
    	      System.err.println("Erro durante a execução do CommandLineRunner: " + e.getMessage());
    	 }
    }
 }