package com.conttroller.tokencontabilidade.enums;

public enum SistemaToken {
    FISCAL,
    CONTABIL,
    FOLHA;
}
