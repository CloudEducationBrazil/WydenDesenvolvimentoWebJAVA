package com.conttroller.tokencontabilidade.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TokenConfig {
    @Value("${token.json.path}")
    private String caminhoArquivoJSON;

    public String getCaminhoArquivoJSON() {
        return caminhoArquivoJSON;
    }
}