package com.conttroller.tokencontabilidade.conttrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.conttroller.tokencontabilidade.services.TokenService;
import com.conttroller.tokencontabilidade.services.ViaCepService;
import com.fasterxml.jackson.databind.JsonNode;

@RestController
@RequestMapping(value="/api/tokencontabilidade")
public class TokenController {
	@Autowired
    private ViaCepService viaCepService;

	@Autowired
    private TokenService tokenService;

	// (envia JSON para criar o token)
	/*POST http://localhost:8585/api/tokencontabilidade
		{
		  "id": 1,
		  "sistema": ["fiscal", "contábil", "folha"],
		  "datalimite": "2025-12-31",
		  "status": "ativo"
		}	*/
	
    @PostMapping
    public ResponseEntity<?> createTokenDTO() {
        return tokenService.createTokenDTO();
    }
    
    // GET http://localhost:8585/api/tokencontabilidade/consultarCep/41720075
    @GetMapping("/consultarCep/{cep}")
    public JsonNode consultarCep(@PathVariable String cep) {
        return viaCepService.consultarCep(cep);
    }
}