package com.conttroller.tokencontabilidade.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;

@Configuration
public class AppConfig {

    //@Bean
    public WebClient.Builder webClientBuilder() {
        // Configura o HttpClient com um tempo de resposta de 5 segundos
        HttpClient httpClient = HttpClient.create()
            .responseTimeout(Duration.ofSeconds(5));

        // Retorna o WebClient.Builder configurado
        return WebClient.builder()
            .baseUrl("https://api.exemplo.com")
            .clientConnector(new ReactorClientHttpConnector(httpClient))
            .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    }
}