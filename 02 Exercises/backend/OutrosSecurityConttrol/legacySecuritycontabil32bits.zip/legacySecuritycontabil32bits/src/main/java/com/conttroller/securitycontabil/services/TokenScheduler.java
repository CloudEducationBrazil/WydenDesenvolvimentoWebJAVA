package com.conttroller.securitycontabil.services;

import org.springframework.context.annotation.DependsOn;
import org.springframework.context.event.EventListener;
import org.springframework.boot.context.event.ApplicationReadyEvent;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@DependsOn("entityManagerFactory")
public class TokenScheduler {

    private final TokenExecutorService tokenExecutorService;

    public TokenScheduler(TokenExecutorService tokenExecutorService) {
        this.tokenExecutorService = tokenExecutorService;
    }
    
    // Executado 1 única vez quando a aplicação terminar de subir
    @EventListener(ApplicationReadyEvent.class)
    public void iniciarScheduler() {
        tokenExecutorService.executarTokenReal();
    }
    
    // Executa a cada 3 horas (10,800,000 ms)
    // Executa a cada 10 min (600,000 ms)
    // initialDelay = 20000 ou 30000
    @Scheduled(initialDelay = 30000, fixedDelay = 600000) // fixedDelay a cada 10 minutos depois do fim da execução anterior ou tempo exato com fixedRate
    public void atualizarTokenPeriodicamente() {
        tokenExecutorService.executarTokenReal();
    }
}