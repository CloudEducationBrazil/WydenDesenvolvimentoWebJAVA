package com.conttroller.securitycontabil.components;

public interface AppTerminator {
    void exit(int status);
}