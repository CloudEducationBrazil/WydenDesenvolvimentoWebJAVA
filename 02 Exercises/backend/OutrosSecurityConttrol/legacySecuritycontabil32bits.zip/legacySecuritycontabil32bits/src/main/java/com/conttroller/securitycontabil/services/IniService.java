package com.conttroller.securitycontabil.services;

import org.ini4j.Ini;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conttroller.securitycontabil.dto.TokenEnvioApiContabilidadeDTO;

import java.io.File;
import java.io.IOException;

@Service
public class IniService {

    private static final Logger logger = LoggerFactory.getLogger(AppExecutionService.class);
    
    @Autowired
    private AppContextService appContextService;

    public TokenEnvioApiContabilidadeDTO carregarEmpresaDoIni(String caminhoArquivo) {
        try {
            Ini ini = new Ini(new File(caminhoArquivo));
            
            String cnpj = ini.get("empresa", "cnpj");

            TokenEnvioApiContabilidadeDTO dto = new TokenEnvioApiContabilidadeDTO();
            dto.setCnpj(cnpj);
            dto.setPassword(appContextService.getInputToken()); // token
            
            return dto;

        } catch (IOException e) {
            //System.err.println("Erro ao ler o arquivo INI: " + e.getMessage());
            logger.warn("[ERRO INI] Erro ao ler o arquivo INI:" + e.getMessage());
            return null;
        }
    }
}