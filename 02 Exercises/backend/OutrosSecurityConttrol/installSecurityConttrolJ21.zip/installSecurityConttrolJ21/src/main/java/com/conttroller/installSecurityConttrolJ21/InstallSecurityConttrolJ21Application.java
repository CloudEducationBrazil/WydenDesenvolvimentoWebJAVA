package com.conttroller.installSecurityConttrolJ21;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;

import com.sun.jna.platform.win32.Advapi32Util;
import com.sun.jna.platform.win32.WinReg;
import com.sun.jna.platform.win32.Crypt32Util;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.nio.file.*;

@SpringBootApplication
public class InstallSecurityConttrolJ21Application {
	
    private static final String JAR_NAME = "securitycontabil.jar";
    private static final String SERVICE_NAME = "TokenService";
    
    private static final String NOME_ARQUIVO = "securityconttrol.ini";
    private static final Path CAMINHO_ARQUIVO = Path.of(NOME_ARQUIVO);
    private static final String SECAO = "[EMPRESA]";    

    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_CYAN = "\u001B[36m";
    
    private static final String REG_PATH = "Software\\Lorttnoc\\Snekot";
    private static final String REG_TOKEN_NAME = "nekot"; // nome do valor do registro   	
    
	public static void main(String[] args) {
		
		try {
			
			if (!isWindows()) {
				abort("Este instalador é exclusivo para Windows.");
			}
			
			// Se Arc 32bits não instalar
			if ( !isWindows64() ) {
				abort("Arquitetura do Windows não é 64bits. Utilizar instalador 32bits.");
			}
		}
		catch (Exception e) {
            abort("Erro na identificação da arquitetura do Windows:" + e.getMessage());
		}		

		SpringApplication.run(InstallSecurityConttrolJ21Application.class, args);
		
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {

            limparTela();
            exibirCabecalho();

            if (!isAdmin()) {
              System.out.println(ANSI_RED + "⚠️ Execute este instalador como Administrador!" + ANSI_RESET);
                return;
            }

            System.out.println("1 - Solicitar Token");
            System.out.println("2 - Instalar Serviço");
            System.out.print("\nEscolha uma opção: ");
            String opcao = reader.readLine().trim();

            switch (opcao) {
                case "1" -> solicitarToken(reader);
                case "2" -> instalarServico(reader);
                default -> System.out.println(ANSI_RED + "❌ Opção inválida!" + ANSI_RESET);
            }
            
        } catch (IOException e) {
            System.err.println(ANSI_RED + "Erro de entrada/saída: " + e.getMessage() + ANSI_RESET);
        }
    }

    private static boolean isAdmin() {
        try {
            Process p = new ProcessBuilder("net", "session").start();
            p.waitFor();
            return p.exitValue() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private static void solicitarToken(BufferedReader reader) throws IOException {
        System.out.println("\n== Solicitação de Token ==");

        // Versão Windows
        System.out.println(versionWindows());
        
        // Solicita caminho completo
        System.out.print("Digite o caminho completo onde o sistema está instalado (ex: C:\\conttroller\\conttrol): ");
        String caminhoInformado = reader.readLine().trim();
        if (caminhoInformado.isEmpty()) {
            System.err.println("Caminho inválido. Encerrando instalação.");
            return;
        }

        File dir = new File(caminhoInformado);
        File jarFile = new File(dir, JAR_NAME);

        if (!dir.exists() || !dir.isDirectory()) {
          System.err.println(ANSI_RED + "❌ O diretório informado não existe: " + caminhoInformado + ANSI_RESET);
            return;
        }

        if (!jarFile.exists()) {
          System.err.println(ANSI_RED + "❌ Arquivo " + JAR_NAME + " não encontrado no caminho informado." + ANSI_RESET);
            return;
        }

        // Solicita CPF/CNPJ
        System.out.print("Digite o CPF ou CNPJ (somente números): ");
        String cnpj = reader.readLine().trim();
        
        if ( cnpj.isEmpty() || ( !cnpj.matches("^\\d{11}$") && 
                !cnpj.matches("^\\d{14}$") ) ) {
            System.err.println("CPF inválido ou CNPJ inválido. Encerrando instalação.");
            return;
        }

        // Estrutura chave-valor para gravação
        var dadosParaGravar = Map.of("CNPJ", cnpj, "CAMINHO", caminhoInformado);

        // 2. Gravar no Arquivo .ini
        gravarConfiguracao(dadosParaGravar);  

        // Caminhos dinâmicos
        String javaPath = caminhoInformado + "\\java\\bin\\java.exe";
        //String gmailAppPassword = System.getenv("GMAIL_APP_PASSWORD");
        String gmailAppPassword = "cofyuorxbeuxabbf";
        
        if (gmailAppPassword == null || gmailAppPassword.isBlank()) {
            System.err.println("❌ Variável GMAIL_APP_PASSWORD não definida.");
            return;
        }
        
        String logPath = caminhoInformado + "\\install.log";

        System.out.println("\nExecutando geração de token...");

        executarProcesso(new String[]{
                javaPath,
                "-Dspring.profiles.active=first",
                "-DGMAIL_APP_PASSWORD=" + gmailAppPassword,
                "-Dspring.autoconfigure.exclude=org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration",
                "-jar", jarFile.getAbsolutePath(),
                cnpj,
                caminhoInformado
        }, "Gerando token e enviando por e-mail...", logPath);
    }

    private static void instalarServico(BufferedReader reader) throws IOException {
        System.out.println("\n== Instalação do Serviço ==");

        // Carregar e Exibir os dados
        var configCarregada = carregarConfiguracao();
        
        // Carregar valor atual do arquivo para usar como sugestão
        String caminhoInformado = configCarregada.getOrDefault("CAMINHO", "Não Encontrado");
        
        if (caminhoInformado.isEmpty()) {
            System.err.println("Caminho inválido. Encerrando instalação.");
            return;
        }

        File dir = new File(caminhoInformado);
        File jarFile = new File(dir, JAR_NAME);

        if (!dir.exists() || !dir.isDirectory()) {
            System.err.println(ANSI_RED + "❌ O diretório informado não existe: " + caminhoInformado + ANSI_RESET);
            return;
        }

        if (!jarFile.exists()) {
            System.err.println(ANSI_RED + "❌ Arquivo " + JAR_NAME + " não encontrado no caminho informado." + ANSI_RESET);
            return;
        }

        // Carregar valor atual do arquivo para usar como sugestão
        String cnpj = configCarregada.getOrDefault("CNPJ", "Não Encontrado");

        System.out.print("\n");
        
        if ( cnpj.isEmpty() || ( !cnpj.matches("^\\d{11}$") && 
        		                 !cnpj.matches("^\\d{14}$") ) ) {
            System.err.println("CPF inválido ou CNPJ inválido. Encerrando instalação.");
            return;
        }

        // Solicita Token
        System.out.print("Digite o TOKEN de autenticação: ");
        String token = reader.readLine().trim();
        
        if (token.isEmpty() || !token.matches("^[A-Za-z0-9._-]{20,}$")) {
            System.err.println("Length Token inválido! Encerrando instalação.");
            return;
        }
        
        //System.out.println("token digitado " + token);
        if ( !validarTokenRegistro(token) ) {
            System.err.println("Token informado inválido! Encerrando instalação.");
            return;
        }

        String javaPath = caminhoInformado + "\\java\\bin\\java.exe";
        String logPath = caminhoInformado + "\\install.log";

        //String arch = System.getenv("PROCESSOR_ARCHITECTURE");
        //String wow64 = System.getenv("PROCESSOR_ARCHITEW6432");
        //boolean is64bit = (arch != null && arch.endsWith("64")) || (wow64 != null && wow64.endsWith("64"));
        boolean is64bit = isWindows64();
        String nssmPath = caminhoInformado + "\\nssm\\" + (is64bit ? "win64" : "win32") + "\\nssm.exe";

        System.out.println("Caminho do JAR: " + jarFile.getAbsolutePath());
        System.out.println("CPF/CNPJ Vinculado: " + formatarCnpj(cnpj));

        System.out.print("\nConfirma instalação do serviço? (S/N): ");
        if (!reader.readLine().trim().equalsIgnoreCase("S")) {
            System.out.println(ANSI_YELLOW + "Instalação cancelada pelo usuário." + ANSI_RESET);
            return;
        }

        executarProcesso(new String[]{nssmPath, "stop", SERVICE_NAME}, "Parando serviço existente (se houver)", logPath);
        executarProcesso(new String[]{nssmPath, "remove", SERVICE_NAME, "confirm"}, "Removendo serviço existente", logPath);
        executarProcesso(new String[]{nssmPath, "install", SERVICE_NAME, javaPath}, "Instalando serviço base", logPath);
        executarProcesso(new String[]{nssmPath, "set", SERVICE_NAME, "AppParameters",
                "-jar \"" + jarFile.getAbsolutePath() + "\" " + cnpj + " \"" + caminhoInformado + "\" \"" + token + "\""},
                "Configurando parâmetros do serviço", logPath);
        executarProcesso(new String[]{nssmPath, "set", SERVICE_NAME, "AppDirectory", caminhoInformado},
                "Configurando diretório de trabalho", logPath);
        executarProcesso(new String[]{nssmPath, "set", SERVICE_NAME, "Start", "SERVICE_AUTO_START"},
                "Configurando inicialização automática", logPath);
        executarProcesso(new String[]{nssmPath, "start", SERVICE_NAME}, "Iniciando serviço", logPath);

        System.out.println(ANSI_GREEN + "\n✅ Serviço instalado e iniciado com sucesso!" + ANSI_RESET);
        log("Serviço instalado com sucesso | Caminho: " + caminhoInformado + " | CPF/CNPJ: " + cnpj, logPath);
        
        log("Limpando dados ...", logPath);
        deleteFiles();
        
        try {
            selfDelete("installSecurityConttrolJ21.jar", "installSecurityConttrolJ21.bat");
		} catch (Exception e) {
            System.err.println("Erro ao excluir o arquivo zip implantação: " + e.getMessage());
		}
    }

    private static void executarProcesso(String[] comando, String descricao, String logPath) {
        try {
            System.out.println(ANSI_CYAN + "\n> " + descricao + "..." + ANSI_RESET);
            ProcessBuilder pb = new ProcessBuilder(comando);
            pb.inheritIO();
            Process process = pb.start();
            process.waitFor();
            log(descricao + ": " + String.join(" ", comando), logPath);
        } catch (Exception e) {
            System.err.println(ANSI_RED + "Erro ao executar comando: " + descricao + " - " + e.getMessage() + ANSI_RESET);
            log("Erro ao executar: " + descricao + " | " + e.getMessage(), logPath);
        }
    }

    private static void limparTela() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } catch (Exception ignored) {}
    }

    private static void exibirCabecalho() {
        System.out.println(ANSI_YELLOW + "============================================" + ANSI_RESET);
        System.out.println(ANSI_GREEN +  "    INSTALADOR SECURITY CONTTROL MODERNO    " + ANSI_RESET);
        System.out.println(ANSI_YELLOW + "============================================\n" + ANSI_RESET);
    }

    private static void log(String msg, String logPath) {
        try {
            File logFile = new File(logPath);
            logFile.getParentFile().mkdirs();
            try (FileWriter fw = new FileWriter(logFile, true)) {
                String data = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
                fw.write(data + " - " + msg + System.lineSeparator());
            }
        } catch (IOException ignored) {}
    }

    private static String formatarCnpj(String cnpj) {
        return cnpj.replaceFirst("(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})", "$1.$2.$3/$4-$5");
    }

    /**
     * Grava os dados em formato [SECAO]\nCHAVE=VALOR no arquivo.
     */
    private static void gravarConfiguracao(Map<String, String> dados) {
        try {
            var sb = new StringBuilder();
            sb.append(SECAO).append("\n"); // Adiciona o cabeçalho da seção
            
            for (var entry : dados.entrySet()) {
                sb.append(entry.getKey()).append("=").append(entry.getValue()).append("\n");
            }
            
            // Usando o Files.writeString (Java 21) para escrita simples
            Files.writeString(CAMINHO_ARQUIVO, sb.toString());
            System.out.println("\n Dados salvos em: " + NOME_ARQUIVO);
            
        } catch (IOException e) {
            System.err.println("Erro ao gravar o arquivo .ini: " + e.getMessage());
        }
    } 
    
    /**
     * Carrega os dados do arquivo .ini, buscando pela seção [EMPRESA].
     */
    private static Map<String, String> carregarConfiguracao() {
        var configuracao = new HashMap<String, String>();
        
        if (!Files.exists(CAMINHO_ARQUIVO)) {
            System.err.println("\nArquivo de configuração não encontrado!");
            return configuracao;
        }

        try {
            // Usando o Files.readString (Java 21) para leitura simples
            var conteudo = Files.readString(CAMINHO_ARQUIVO);
            
            // Usando o String.lines() (Java 21) e Stream para processar as linhas
            conteudo.lines()
                    .map(String::trim)
                    .filter(line -> !line.isEmpty() && !line.startsWith(";"))
                    .forEach(line -> {
                        // O parser é simplificado: só processa chave=valor dentro da seção correta
                        if (line.equals(SECAO)) {
                            // Encontrou a seção, o que é útil se houvessem múltiplas seções
                        } else if (line.contains("=")) {
                            var partes = line.split("=", 2);
                            if (partes.length == 2) {
                                configuracao.put(partes[0].trim(), partes[1].trim());
                            }
                        }
                    });

        } catch (IOException e) {
            System.err.println("Erro de leitura do arquivo .ini: " + e.getMessage());
        }
        return configuracao;
    }
    
    private static boolean validarTokenRegistro(String tokenInformado) {
        try {
            WinReg.HKEY root = WinReg.HKEY_LOCAL_MACHINE;

            if (!Advapi32Util.registryKeyExists(root, REG_PATH)) {
                System.err.println("⚠ Chave de registro não encontrada: HKLM\\" + REG_PATH);
                return false;
            }

            if (!Advapi32Util.registryValueExists(root, REG_PATH, REG_TOKEN_NAME)) {
                System.err.println("⚠ Valor 'token' não encontrado no Windows.");
                return false;
            }

            // valor BASE64
            //String base64 = Advapi32Util.registryGetStringValue(root, REG_PATH, REG_TOKEN_NAME);
            //System.out.println("base6: " + base64);
            
            byte[] encrypted = Advapi32Util.registryGetBinaryValue(root, REG_PATH, REG_TOKEN_NAME);

            // descriptografa DPAPI
            //byte[] plain = Crypt32Util.cryptUnprotectData(Base64.getDecoder().decode(base64));
            //System.out.println("plain: " + plain);
            
            byte[] plain = Crypt32Util.cryptUnprotectData(encrypted);

            String tokenNoRegistro = new String(plain, StandardCharsets.UTF_8);
            //System.out.println("tokenNoRegistro: " + tokenNoRegistro);
            
            if (!tokenInformado.equals(tokenNoRegistro)) {
                System.err.println("❌ Token [INFORMADO] não coincide com o [GERADO]:");
                //System.err.println("   Registro : " + tokenNoRegistro);
                //System.err.println("   Informado: " + tokenInformado);
                return false;
            }

            return true;

        } catch (Exception e) {
            System.err.println("❌ Erro ao acessar o registro: " + e.getMessage());
            return false;
        }
    }
    
    private static void deleteFiles() {
        try {
            // Diretório onde o JAR está rodando
            String jarDir = new File(".").getCanonicalPath();

            String logPath = jarDir + "\\install.log";
            log("Limpando dados .zip ...", logPath);
            
            // Apagar o arquivo ZIP
            Path zipPath = Paths.get(jarDir, "implantationSecurityConttrolJava21.zip");
            if (Files.deleteIfExists(zipPath)) {
                System.out.println("Arquivo .zip excluído: " + zipPath);
            }
            
            // Apagar a pasta implantationSecurityConttrolJava21 COMPLETA
            Path folderPath = Paths.get(jarDir, "implantationSecurityConttrolJava21");
            
            if (Files.exists(folderPath)) {
                try (var stream = Files.walk(folderPath)) {
                    stream
                        .sorted(Comparator.reverseOrder()) // filhos primeiro
                        .forEach(p -> {
                            try {
                                Files.deleteIfExists(p);
                            } catch (Exception e) {
                                System.err.println("Falha ao excluir: " + p + " → " + e.getMessage());
                            }
                        });
                }
                System.out.println("Pasta implantationSecurityConttrolJava21 excluída: " + folderPath);
            }
            
        } catch (Exception e) {
            System.err.println("Erro ao excluir arquivo .zip: " + e.getMessage());
        }
    }
    
    public static void selfDelete(String jarNameToDelete, String batToDelete) throws Exception {
        // Caminho atual onde o JAR está rodando
        String currentDir = new File(".").getCanonicalPath();

        String deleteBat = currentDir + "\\delete_temp.bat";
        
        String logPath = currentDir + "\\install.log";

        log("Limpando dados .jar ...", logPath);
        log("Limpando dados .bat ...", logPath);

        String content =
                "@echo off\n" +
                "echo Aguardando finalizar...\n" +
                "timeout /t 3 > NUL\n" +        // espera o jar encerrar e liberar o arquivo
                "del \"" + currentDir + "\\" + jarNameToDelete + "\"\n" + 
                "del \"" + currentDir + "\\" + batToDelete + "\"\n" +
                "del \"%~f0\"\n";              // apaga o próprio script (self-delete)

        Files.write(Paths.get(deleteBat), content.getBytes());

        // Executa o .bat de exclusão
        //new ProcessBuilder("cmd", "/c", "start", "", deleteBat)
        //        .inheritIO()
        //        .start();

        new ProcessBuilder(
                "cmd",
                "/c",
                "\"" + deleteBat + "\""
        ).inheritIO().start();

        System.exit(0); // encerra o JAR
    }
    
    public static boolean isWindows64() {
        // Primeiro tenta detectar via propriedades da JVM
        String osArch = System.getProperty("os.arch");
        if (osArch != null && osArch.toLowerCase().contains("64")) {
            return true;
        }

        // Depois tenta variáveis de ambiente do Windows
        String procArch = System.getenv("PROCESSOR_ARCHITECTURE");
        String procArchWow = System.getenv("PROCESSOR_ARCHITEW6432");

        return (procArch != null && procArch.contains("64"))
            || (procArchWow != null && procArchWow.contains("64"));
    }
    
    private static boolean isWindows() {
        return System.getProperty("os.name", "")
                .toLowerCase(Locale.ROOT)
                .startsWith("windows");
    }
    
    private static void abort(String msg) {
        System.err.println(msg);
        System.exit(1);
    }
    
    private static String versionWindows() {
        return System.getProperty("os.name", "Windows") + " v. "
             + System.getProperty("os.version", "Desconhecida");
    }
}