package com.conttroller.securitycontabil.services;

import java.io.File;
import java.security.SecureRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conttroller.securitycontabil.dto.TokenEnvioApiContabilidadeDTO;

@Service
public class TokenExecutorService {

    private static final Logger logger = LoggerFactory.getLogger(TokenExecutorService.class);

    @Autowired
    private TokenService tokenService;

    @Autowired
    private AppContextService contextService;

    @Autowired
    private EmailSender emailSender;

    private String tokenGerado;

    public void gerarEEnviarToken() throws Exception {
        SecureRandom random = new SecureRandom();
        tokenGerado = String.format("%06d", random.nextInt(1_000_000));

        enviarTokenEmail(tokenGerado);
    }

    private void enviarTokenEmail(String token) throws Exception {
        String emailDiretor = "helenocardosofilho@gmail.com";
        String assunto = "Token de registro do sistema Conttrol.";
        String corpo = "Token para autorizar registrar o app java como serviço do Windows: " + token;

        emailSender.sendEmail(emailDiretor, assunto, corpo);
        logger.info("Token enviado por e-mail (real).");
    }

    public boolean validarToken(String tokenFornecido) {
        return tokenFornecido != null && tokenFornecido.equals(tokenGerado);
    }

   // public void executarRegistroService() throws Exception {
 //       logger.info("Serviço registrado com sucesso (simulação).");
//    }
    
    /**
     * Executa a geração do token para o CNPJ e caminho configurados.
     * Pode ser chamada tanto na inicialização quanto periodicamente.
     */
    public void executarToken() {
        String cnpj = contextService.getCnpj();
        File caminho = contextService.getCaminho();

        if (cnpj == null || cnpj.isBlank()) {
            logger.warn("CNPJ não configurado. Ignorando execução do token.");
            return;
        }

        if (caminho == null) {
            caminho = new File("C:\\conttrol\\");
            contextService.setCaminho(caminho);
            logger.info("Caminho não configurado. Usando padrão: {}", caminho.getAbsolutePath());
        }

        try {
            TokenEnvioApiContabilidadeDTO body = new TokenEnvioApiContabilidadeDTO(cnpj, "", caminho);
            tokenService.postTokenContabilidade(body);
            logger.info("Token processado com sucesso para o CNPJ: {}", cnpj);
        } catch (Exception e) {
            logger.error("Erro ao processar token para o CNPJ {}: {}", cnpj, e.getMessage(), e);
        }
    }
}