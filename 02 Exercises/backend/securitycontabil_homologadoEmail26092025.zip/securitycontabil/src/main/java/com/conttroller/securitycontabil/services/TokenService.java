package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.dto.*;
import com.conttroller.securitycontabil.entities.Token;
import com.conttroller.securitycontabil.interfaces.TokenClient;
import com.conttroller.securitycontabil.repositories.TokenRepository;
import com.conttroller.securitycontabil.utils.RC4Util;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jna.platform.win32.Advapi32Util;
import com.sun.jna.platform.win32.WinReg;
import feign.FeignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

import com.sun.jna.platform.win32.Crypt32Util;

import java.time.Instant;
import java.util.Base64;

@Service
public class TokenService {

    private static final Logger logger = LoggerFactory.getLogger(TokenService.class);

    @Autowired
    private TokenClient tokenClient;

    @Autowired
    private TokenRepository tokenRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private AppContextService appContextService;

    private final String password = "lorttnocToken2025@";
    private final String registryKey = "Software\\Lorttnoc\\Snekot";

    @Transactional
    public void carregarTokens() {
        String cnpjAtual = appContextService.getCnpj();
        File pastaTokens = appContextService.getCaminho();

        boolean h2Vazio = tokenRepository.count() == 0;
        Optional<TokenRetornoApiContabilidadeDTO> dtoRegistro = lerTokensRegistro();

        if (cnpjAtual != null && pastaTokens != null) {
            // Sempre tenta a API primeiro
            carregarTokensDaAPI(cnpjAtual, pastaTokens);
        } else if (h2Vazio && dtoRegistro.isPresent()) {
            // H2 vazio, carregando do registro
            logger.info("H2 vazio. Populando tokens a partir do Registro do Windows...");
            salvarTokensH2(dtoRegistro.get());
        } else if (h2Vazio) {
            // Primeira execução sem CNPJ → não pode prosseguir
            logger.warn("Primeira execução requer CNPJ configurado. Nenhum token carregado.");
        } else {
            // H2 já possui tokens → nada a fazer
            logger.info("Tokens já existentes no H2. Nenhuma ação necessária.");
        }
    }

    private void carregarTokensDaAPI(String cnpj, File pastaTokens) {
        TokenEnvioApiContabilidadeDTO dtoEnvio = new TokenEnvioApiContabilidadeDTO();
        
        dtoEnvio.setCnpj(cnpj);
        dtoEnvio.setCaminho(pastaTokens);
        dtoEnvio.setPassword(password);

        try {
            TokenRetornoApiContabilidadeDTO dtoCompleto = tokenClient.postToken(dtoEnvio);
            TokenRetornoApiContabilidadeMinDTO dtoMin = mapearParaMinDTO(dtoCompleto);

            salvarTokenEmDisco(dtoCompleto, dtoMin, pastaTokens);
            salvarTokensH2(dtoCompleto);
            salvarTokensRegistro(dtoCompleto);

            logger.info("Tokens carregados com sucesso da API.");

        } catch (FeignException e) {
            logger.warn("API indisponível, tentando carregar tokens do Registro do Windows... [{}]", e.status());
            lerTokensRegistro().ifPresent(this::salvarTokensH2);
        } catch (Exception e) {
            logger.error("Erro inesperado ao carregar tokens: {}", e.getMessage(), e);
        }
    }

    private void salvarTokensH2(TokenRetornoApiContabilidadeDTO dtoCompleto) {
        if (dtoCompleto.getServidor() != null && dtoCompleto.getServidor().getSistemas() != null) {
            dtoCompleto.getServidor().getSistemas().forEach(sistema -> {
                String nomeSistema = sistema.getSistema();
                if (sistema.getModulos() != null && !sistema.getModulos().isEmpty()) {
                    var settings = sistema.getModulos().get(0).getSettings();
                    if (settings != null) {
                        Optional<Token> tokenOpt = tokenRepository.findBySistemaAndCnpj(nomeSistema, dtoCompleto.getCnpj());
                        Token token = tokenOpt.orElseGet(Token::new);

                        token.setCnpj(dtoCompleto.getCnpj());
                        token.setValidade(dtoCompleto.getValidade());
                        token.setSistema(nomeSistema);
                        token.setHabilitado(settings.getHabilitado());
                        token.setFinanceiro(settings.getStatusFin());

                        tokenRepository.save(token);
                    }
                }
            });
        }
    }

 // grava no registro usando DPAPI (CryptProtectData)
    private void salvarTokensRegistro(TokenRetornoApiContabilidadeDTO dtoCompleto) {
        try {
            String json = objectMapper.writeValueAsString(dtoCompleto);
            byte[] plainBytes = json.getBytes(StandardCharsets.UTF_8);

            // Protege com DPAPI para o contexto do usuário local (padrão DPAPI)
            byte[] protectedBytes = Crypt32Util.cryptProtectData(plainBytes);

            // gravamos no registro como Base64 para não misturar bytes binários
            String b64 = Base64.getEncoder().encodeToString(protectedBytes);

            Advapi32Util.registryCreateKey(WinReg.HKEY_CURRENT_USER, registryKey);
            Advapi32Util.registrySetStringValue(WinReg.HKEY_CURRENT_USER, registryKey, "TokensDPAPI", b64);
            Advapi32Util.registrySetStringValue(WinReg.HKEY_CURRENT_USER, registryKey, "SavedAt", Instant.now().toString());

            logger.info("Tokens gravados no Registro (criptografados com DPAPI).");
        } catch (Exception e) {
            logger.error("Erro ao salvar tokens no Registro (DPAPI): {}", e.getMessage(), e);
        }
    }
    
    @Transactional
    public ResponseEntity<TokenRetornoApiContabilidadeDTO> postTokenContabilidade(TokenEnvioApiContabilidadeDTO body) {
        if (body.getCnpj() == null || body.getCnpj().isBlank()) {
            logger.warn("CNPJ inválido no corpo da requisição.");
            return ResponseEntity.badRequest().build();
        }

        File caminho = body.getCaminho();
        TokenRetornoApiContabilidadeDTO dtoCompleto = null;

        try {
            // Chama API externa
            dtoCompleto = tokenClient.postToken(body);

            // Mapeia para DTO reduzido
            TokenRetornoApiContabilidadeMinDTO dtoMin = mapearParaMinDTO(dtoCompleto);

            // Salva JSONs criptografados em disco
            salvarTokenEmDisco(dtoCompleto, dtoMin, caminho);

            // Salva cada sistema na tabela tb_token
            if (dtoCompleto.getServidor() != null && dtoCompleto.getServidor().getSistemas() != null) {
                dtoCompleto.getServidor().getSistemas().forEach(sistema -> {
                    //String nomeSistema = sistema.getSistema();
                    if (sistema.getModulos() != null && !sistema.getModulos().isEmpty()) {
                        var settings = sistema.getModulos().get(0).getSettings();
                        if (settings != null) {
                            // Verifica se já existe o registro para este sistema
                            /*<Optional<Token> tokenOpt = tokenRepository.findBySistema(nomeSistema);
                            Token token = tokenOpt.orElseGet(Token::new);

                            token.setSistema(nomeSistema);
                            token.setHabilitado(settings.getHabilitado());
                            token.setFinanceiro(settings.getStatusFin());

                            tokenRepository.save(token); // salva ou atualiza
                            */
                        }
                    }
                });
            }

            logDetalhesDto(dtoCompleto);

        } catch (FeignException e) {
            logger.error(">>> Erro ao chamar API externa: {}", e.getMessage(), e);
            return ResponseEntity.status(e.status()).build();
        } catch (JsonProcessingException e) {
            logger.error(">>> Erro ao processar JSON: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } catch (Exception e) {
            logger.error(">>> Erro inesperado: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

        return ResponseEntity.ok(dtoCompleto);
    }
    
	@Transactional
	private void logDetalhesDto(TokenRetornoApiContabilidadeDTO dtoCompleto) {
		if (dtoCompleto.getServidor() != null) {
			logger.info("Token gerado com sucesso para CNPJ: {}", dtoCompleto.getCnpj());
		    logger.info(">>> Lista de sistemas: {}", dtoCompleto.getServidor().getSistemas());
			logger.info(">>> Servidor DTO recebido: {}", dtoCompleto.getServidor());
			logger.info(">>> DTO recebido: {}", dtoCompleto);
		}
		
	    if (dtoCompleto.getServidor().getSistemas() != null) {
	    	dtoCompleto.getServidor().getSistemas().forEach(sistema -> {
	            logger.info(">>> Sistema: {}", sistema);
	            if (sistema.getModulos() != null) {
	                sistema.getModulos().forEach(modulo -> {
	                    logger.info(">>> Módulo: {}", modulo);
	                    logger.info(">>> Settings do módulo: {}", modulo.getSettings());
	                });
	            }
	        });
	    }
	}

    // lê do registro e tenta descriptografar com DPAPI
    private Optional<TokenRetornoApiContabilidadeDTO> lerTokensRegistro() {
        try {
            if (!Advapi32Util.registryKeyExists(WinReg.HKEY_CURRENT_USER, registryKey)) {
                return Optional.empty();
            }

            if (!Advapi32Util.registryValueExists(WinReg.HKEY_CURRENT_USER, registryKey, "TokensDPAPI")) {
                logger.debug("Chave TokensDPAPI não encontrada no registro.");
                return Optional.empty();
            }

            String b64 = Advapi32Util.registryGetStringValue(WinReg.HKEY_CURRENT_USER, registryKey, "TokensDPAPI");
            if (b64 == null || b64.isBlank()) {
                logger.warn("TokensDPAPI vazio no registro.");
                return Optional.empty();
            }

            byte[] protectedBytes = Base64.getDecoder().decode(b64);

            // Tenta descriptografar — se falhar, significa que não é o mesmo contexto (usuário/máquina)
            byte[] plainBytes;
            try {
                plainBytes = Crypt32Util.cryptUnprotectData(protectedBytes);
            } catch (Exception dpapiEx) {
                logger.warn("Falha ao descriptografar TokensDPAPI com DPAPI: {}. Possível cópia para outra máquina/usuário.", dpapiEx.getMessage());
                return Optional.empty();
            }

            String json = new String(plainBytes, StandardCharsets.UTF_8);
            if (json == null || json.isBlank()) {
                logger.warn("JSON descriptografado está vazio.");
                return Optional.empty();
            }

            TokenRetornoApiContabilidadeDTO dto = objectMapper.readValue(json, TokenRetornoApiContabilidadeDTO.class);
            
            logger.info("Tokens carregados do Registro e descriptografados com DPAPI com sucesso.");
            return Optional.of(dto);

        } catch (Exception e) {
            logger.error("Erro ao ler tokens do Registro (DPAPI): {}", e.getMessage(), e);
            return Optional.empty();
        }
    }
    
    private TokenRetornoApiContabilidadeMinDTO mapearParaMinDTO(TokenRetornoApiContabilidadeDTO dtoCompleto) {
        TokenRetornoApiContabilidadeMinDTO dtoMin = new TokenRetornoApiContabilidadeMinDTO();
        
        dtoMin.setId(dtoCompleto.getId());
        dtoMin.setCnpj(dtoCompleto.getCnpj());
        dtoMin.setValidade(dtoCompleto.getValidade());
        dtoMin.setAssinatura(dtoCompleto.getAssinatura());

        if (dtoCompleto.getServidor() != null && dtoCompleto.getServidor().getSistemas() != null) {
            dtoCompleto.getServidor().getSistemas().forEach(sistema -> {
                
            	String nome = sistema.getSistema();
                if (sistema.getModulos() != null && !sistema.getModulos().isEmpty()) {
                    var settings = sistema.getModulos().get(0).getSettings();
                    if (settings != null) {
                        TokenRetornoApiContabilidadeMinDTO.SistemaDTO sistemaMin = new TokenRetornoApiContabilidadeMinDTO.SistemaDTO();
                        
                        sistemaMin.setHabilitado(settings.getHabilitado());
                        sistemaMin.setStatusFin(settings.getStatusFin());

                        switch (nome.toUpperCase()) {
                            case "FISCAL" -> dtoMin.setFiscal(sistemaMin);
                            case "CONTABIL" -> dtoMin.setContabil(sistemaMin);
                            case "FOLHA" -> dtoMin.setFolha(sistemaMin);
                        }
                    }
                }
            });
        }
        return dtoMin;
    }

    private void salvarTokenEmDisco(TokenRetornoApiContabilidadeDTO completo, TokenRetornoApiContabilidadeMinDTO reduzido, File caminho) throws IOException {
        caminho.mkdirs();

        String jsonOriginal = objectMapper.writeValueAsString(completo);
        String jsonReduzido = objectMapper.writeValueAsString(reduzido);

        String encryptedO = RC4Util.encrypt(jsonOriginal, password);
        String encryptedR = RC4Util.encrypt(jsonReduzido, password);

        String basePath = caminho.getAbsolutePath() + File.separator;
        String arqOriginalEnc = String.format("%stoken_contabilidade_ori_%s.enc", basePath, completo.getCnpj());
        String arqReduzidoEnc = String.format("%stoken_contabilidade_red_%s.enc", basePath, completo.getCnpj());

        try (FileWriter fw = new FileWriter(arqOriginalEnc)) { fw.write(encryptedO); }
        try (FileWriter fw = new FileWriter(arqReduzidoEnc)) { fw.write(encryptedR); }

        logger.info("JSON reduzido criptografado salvo em: {}", arqReduzidoEnc);
    }
}