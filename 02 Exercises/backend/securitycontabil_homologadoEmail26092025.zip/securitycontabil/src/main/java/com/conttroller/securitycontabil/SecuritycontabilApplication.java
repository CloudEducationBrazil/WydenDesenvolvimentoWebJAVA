package com.conttroller.securitycontabil;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.conttroller.securitycontabil.services.AppContextService;
import com.conttroller.securitycontabil.services.TokenExecutorService;
import org.springframework.beans.factory.annotation.Value;

@EnableFeignClients(basePackages = "com.conttroller.securitycontabil.interfaces")
@EnableScheduling
@SpringBootApplication
public class SecuritycontabilApplication implements CommandLineRunner {
	
    @Autowired
    private AppContextService contextService;
    
    @Autowired
    private TokenExecutorService tokenExecutorService;
    
    @Value("${cnpj.default:}")
    private String defaultCnpj;   
    
    @Value("${caminho.default:}")
    private String defaultCaminho;
    
	public static void main(String[] args) {
		SpringApplication.run(SecuritycontabilApplication.class, args);
	}

    @Override
    public void run(String... args) throws Exception {

   	 //       if (args.length < 2) {
//      throw new IllegalArgumentException("Uso: java -jar app.jar <CNPJ> <Caminho> [<Token>]");
//   }

    	String cnpj = (args.length > 0 && !args[0].isBlank()) ? args[0] : defaultCnpj;
        String caminhoStr = (args.length > 1 && !args[1].isBlank()) ? args[1] : defaultCaminho;

//        if (cnpj == null || cnpj.isBlank()) {
//            throw new IllegalArgumentException("CNPJ não informado. Uso: java -jar app.jar <cnpj> <caminho> <smsToken>");
//        }
        
//        if (caminhoStr == null || caminhoStr.isBlank()) {
//            throw new IllegalArgumentException("Caminho não informado. Uso: java -jar app.jar <cnpj> <caminho> <smsToken>");
//        }
        
        contextService.setCnpj(cnpj);
        contextService.setCaminho(new File(caminhoStr));

///        if (smsToken == null || smsToken.isBlank()) {
//            throw new IllegalArgumentException("Token SMS não informado. Uso: java -jar app.jar <cnpj> <caminho> <smsToken>");
 //       }

        if (args.length == 2) {
            // Primeira execução → gerar e enviar token
            tokenExecutorService.gerarEEnviarToken();
            System.out.println("Primeira execução concluída. Token enviado para o diretor.");

             return;
        }

        if (args.length == 3) {
            // Segunda execução → validar token
            String tokenFornecido = args[2];
            contextService.setInputToken(tokenFornecido);
            if (!tokenExecutorService.validarToken(tokenFornecido)) {
                throw new SecurityException("Token inválido. Registro do serviço abortado.");
            }

            // Token correto → registrar serviço
            //tokenExecutorService.executarRegistroService();
            return;
        }

       // throw new IllegalArgumentException("Número de argumentos inválido.");
      
//        tokenExecutorService.executarToken(); // chama o método unificado    }
    }
}