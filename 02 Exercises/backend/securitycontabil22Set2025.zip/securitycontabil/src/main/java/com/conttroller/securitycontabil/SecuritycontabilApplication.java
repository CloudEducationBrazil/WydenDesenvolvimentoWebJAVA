package com.conttroller.securitycontabil;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.conttroller.securitycontabil.services.AppContextService;
import com.conttroller.securitycontabil.services.TokenExecutorService;
import org.springframework.beans.factory.annotation.Value;

@EnableFeignClients(basePackages = "com.conttroller.securitycontabil.interfaces")
@EnableScheduling
@SpringBootApplication
public class SecuritycontabilApplication implements CommandLineRunner {
	
//    @Autowired
//    private TokenService tokenService;
    
    @Autowired
    private AppContextService contextService;
    
    @Autowired
    private TokenExecutorService tokenExecutorService;
    
    @Value("${cnpj.default:}")
    private String defaultCnpj;   
    
    @Value("${caminho.default:}")
    private String defaultCaminho;
    
	public static void main(String[] args) {

        /*i f (args.length == 0 || args[0].isEmpty()) {
            System.err.println("CNPJ não informado. Uso: java -jar app.jar <cnpj>");
            System.exit(1);
        } */
        
		SpringApplication.run(SecuritycontabilApplication.class, args);
	}

    @Override
    public void run(String... args) {
        String cnpj = (args.length > 0 && !args[0].isBlank()) ? args[0] : defaultCnpj;
        String caminhoStr = (args.length > 1 && !args[1].isBlank()) ? args[1] : defaultCaminho;

        contextService.setCnpj(cnpj);
        contextService.setCaminho(new File(caminhoStr));

        tokenExecutorService.executarToken(); // chama o método unificado    }
    }
}