package com.conttroller.securitycontabil.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class TokenInitializer {

    @Autowired
    private TokenService tokenService;

    @EventListener(ApplicationReadyEvent.class)
    public void initTokens() {
        tokenService.carregarTokens();
    }
}