package com.conttroller.securitycontabil.services;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conttroller.securitycontabil.dto.TokenEnvioApiContabilidadeDTO;

@Service
public class TokenExecutorService {

    private static final Logger logger = LoggerFactory.getLogger(TokenExecutorService.class);

    @Autowired
    private TokenServiceAnterior tokenServiceAnterior;

    @Autowired
    private AppContextService contextService;

    /**
     * Executa a geração do token para o CNPJ e caminho configurados.
     * Pode ser chamada tanto na inicialização quanto periodicamente.
     */
    public void executarToken() {
        String cnpj = contextService.getCnpj();
        File caminho = contextService.getCaminho();

        if (cnpj == null || cnpj.isBlank()) {
            logger.warn("CNPJ não configurado. Ignorando execução do token.");
            return;
        }

        if (caminho == null) {
            caminho = new File("C:\\conttrol\\");
            contextService.setCaminho(caminho);
            logger.info("Caminho não configurado. Usando padrão: {}", caminho.getAbsolutePath());
        }

        try {
            TokenEnvioApiContabilidadeDTO body = new TokenEnvioApiContabilidadeDTO(cnpj, "", caminho);
            tokenServiceAnterior.postTokenContabilidade(body);
            logger.info("Token processado com sucesso para o CNPJ: {}", cnpj);
        } catch (Exception e) {
            logger.error("Erro ao processar token para o CNPJ {}: {}", cnpj, e.getMessage(), e);
        }
    }
}