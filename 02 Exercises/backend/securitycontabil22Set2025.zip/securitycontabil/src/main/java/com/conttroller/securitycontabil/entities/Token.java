package com.conttroller.securitycontabil.entities;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_token")
public class Token {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String cnpj;

    @Column(name = "sistema", unique = true)
    private String sistema;
    private String habilitado;
    private String financeiro;

    public Token() {}

    public Token(String cnpj, String sistema, String habilitado, String financeiro) {
    	this.cnpj = cnpj;
    	this.sistema = sistema;
        this.habilitado = habilitado;
        this.financeiro = financeiro;
    }

    public Long getId() { return id; }
   
    public String getCnpj() { return cnpj; }
    public String getSistema() { return sistema; }
    public String getHabilitado() { return habilitado; }
    public String getFinanceiro() { return financeiro; }

	public void setId(Long id) {
		this.id = id;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public void setSistema(String sistema) {
		this.sistema = sistema;
	}

	public void setHabilitado(String habilitado) {
		this.habilitado = habilitado;
	}

	public void setFinanceiro(String financeiro) {
		this.financeiro = financeiro;
	}

	@Override
	public String toString() {
		return "Token [id=" + id + ", cnpj =" + cnpj + ", sistema=" + sistema + ", habilitado=" + habilitado + ", financeiro=" + financeiro
				+ "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Token other = (Token) obj;
		return Objects.equals(id, other.id);
	}
}