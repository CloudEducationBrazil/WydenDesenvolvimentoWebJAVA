INSERT INTO tb_token (sistema, habilitado, financeiro) VALUES ('CONTABIL', 'A', 'N');
INSERT INTO tb_token (sistema, habilitado, financeiro) VALUES ('FISCAL', 'A', 'D');
INSERT INTO tb_token (sistema, habilitado, financeiro) VALUES ('FOLHA', 'I', 'D');