package com.conttroller.installSecurityConttrolJ21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstallSecurityConttrolJ21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
