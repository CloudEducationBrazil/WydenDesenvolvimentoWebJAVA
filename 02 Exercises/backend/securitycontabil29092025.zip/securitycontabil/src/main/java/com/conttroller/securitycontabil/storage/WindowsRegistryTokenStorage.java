package com.conttroller.securitycontabil.storage;

import com.sun.jna.platform.win32.Advapi32Util;
import com.sun.jna.platform.win32.WinReg;
import com.sun.jna.platform.win32.Crypt32Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Optional;

@Component
public class WindowsRegistryTokenStorage implements TokenStorage {

    private static final Logger logger = LoggerFactory.getLogger(WindowsRegistryTokenStorage.class);

    private final String registryKey = "Software\\Lorttnoc\\Snekot"; // seu caminho atual

    @Override
    public void save(String key, String json) throws IOException {
        try {
            byte[] plainBytes = json.getBytes(StandardCharsets.UTF_8);
            byte[] protectedBytes = Crypt32Util.cryptProtectData(plainBytes);
            String b64 = Base64.getEncoder().encodeToString(protectedBytes);
            Advapi32Util.registryCreateKey(WinReg.HKEY_CURRENT_USER, registryKey);
            Advapi32Util.registrySetStringValue(WinReg.HKEY_CURRENT_USER, registryKey, key, b64);
        } catch (Exception e) {
            logger.error("Erro ao salvar no registro (DPAPI): {}", e.getMessage(), e);
            throw new IOException("Erro ao salvar no registro", e);
        }
    }

    @Override
    public Optional<String> load(String key) throws IOException {
        try {
            if (!Advapi32Util.registryKeyExists(WinReg.HKEY_CURRENT_USER, registryKey)) {
                return Optional.empty();
            }
            if (!Advapi32Util.registryValueExists(WinReg.HKEY_CURRENT_USER, registryKey, key)) {
                return Optional.empty();
            }
            String b64 = Advapi32Util.registryGetStringValue(WinReg.HKEY_CURRENT_USER, registryKey, key);
            if (b64 == null || b64.isBlank()) return Optional.empty();

            byte[] protectedBytes = Base64.getDecoder().decode(b64);
            byte[] plainBytes = Crypt32Util.cryptUnprotectData(protectedBytes);
            String json = new String(plainBytes, StandardCharsets.UTF_8);
            return Optional.ofNullable(json);
        } catch (Exception e) {
            logger.warn("Falha ao ler do registro (DPAPI): {}", e.getMessage());
            return Optional.empty();
        }
    }

    @Override
    public void delete(String key) throws IOException {
        try {
            if (Advapi32Util.registryValueExists(WinReg.HKEY_CURRENT_USER, registryKey, key)) {
                Advapi32Util.registryDeleteValue(WinReg.HKEY_CURRENT_USER, registryKey, key);
            }
        } catch (Exception e) {
            logger.warn("Falha ao remover chave no registro: {}", e.getMessage());
            throw new IOException(e);
        }
    }
}