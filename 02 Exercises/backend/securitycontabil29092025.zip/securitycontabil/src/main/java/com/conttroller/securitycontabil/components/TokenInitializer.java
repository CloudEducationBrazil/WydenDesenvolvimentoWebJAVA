package com.conttroller.securitycontabil.components;

import com.conttroller.securitycontabil.services.TokenService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class TokenInitializer {

    private static final Logger logger = LoggerFactory.getLogger(TokenInitializer.class);
    private final TokenService tokenService;

    public TokenInitializer(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void initTokens() {
        try {
            logger.info("Iniciando carregamento automático de tokens...");
            tokenService.carregarTokens(); // Chamada sem parâmetros
            logger.info("Tokens carregados com sucesso.");
        } catch (Exception e) {
            logger.error("Falha ao carregar tokens na inicialização: {}", e.getMessage(), e);
        }
    }
}