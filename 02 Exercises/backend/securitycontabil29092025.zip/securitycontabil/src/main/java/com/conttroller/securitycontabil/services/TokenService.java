package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.dto.*;
import com.conttroller.securitycontabil.entities.Token;
import com.conttroller.securitycontabil.interfaces.TokenClient;
import com.conttroller.securitycontabil.repositories.TokenRepository;
import com.conttroller.securitycontabil.storage.TokenStorage;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Optional;

@Service
public class TokenService {

    private static final Logger logger = LoggerFactory.getLogger(TokenService.class);
    private static final String PASSWORD_DEFAULT = "lorttnocToken2025@";

    private final TokenClient tokenClient;
    private final TokenRepository tokenRepository;
    private final ObjectMapper objectMapper;
    private final AppContextService appContextService;
    private final TokenStorage tokenStorage;

    public TokenService(TokenClient tokenClient,
                        TokenRepository tokenRepository,
                        ObjectMapper objectMapper,
                        AppContextService appContextService,
                        TokenStorage tokenStorage) {
        this.tokenClient = tokenClient;
        this.tokenRepository = tokenRepository;
        this.objectMapper = objectMapper;
        this.appContextService = appContextService;
        this.tokenStorage = tokenStorage;
    }

    /** Carrega tokens da API ou, se falhar, do storage/H2 */
    public void carregarTokens() {
        String cnpj = appContextService.getCnpj();
        File pastaTokens = appContextService.getCaminho();
        boolean h2Vazio = tokenRepository.count() == 0;

        logger.info("Iniciando carregamento de tokens. CNPJ={}, pastaTokens={}, H2 vazio={}", cnpj, pastaTokens, h2Vazio);

        if (cnpj != null && pastaTokens != null) {
            logger.info("Tentando carregar tokens da API...");
            carregarTokensDaAPI(cnpj, pastaTokens);
        } else if (h2Vazio) {
            logger.info("API indisponível ou CNPJ/pasta não configurados. Tentando carregar tokens do storage...");
            carregarTokensDoStorage();
        } else {
            logger.info("Tokens já existentes no H2. Verificando sistemas e módulos:");

            tokenRepository.findAll().forEach(token -> 
                logger.info("Token existente: CNPJ={}, Sistema={}, Habilitado={}, Financeiro={}, Validade={}",
                            token.getCnpj(), token.getSistema(), token.getHabilitado(),
                            token.getFinanceiro(), token.getValidade())
            );
        }
    }
    
    private void salvarTokensH2(TokenRetornoApiContabilidadeDTO dto) {
        if (dto.getServidor() != null && dto.getServidor().getSistemas() != null) {
            dto.getServidor().getSistemas().forEach(sistema -> {
                if (sistema.getModulos() != null && !sistema.getModulos().isEmpty()) {
                    var settings = sistema.getModulos().get(0).getSettings();
                    if (settings != null) {
                        String cnpj = dto.getCnpj();
                        String nomeSistema = sistema.getSistema();

                        Token token = tokenRepository.findByCnpjAndSistema(cnpj, nomeSistema)
                                .orElseGet(Token::new); // cria novo se não existir

                        token.setCnpj(cnpj);
                        token.setSistema(nomeSistema);
                        token.setHabilitado(settings.getHabilitado());
                        token.setFinanceiro(settings.getStatusFin());
                        token.setValidade(dto.getValidade());

                        tokenRepository.save(token);

                        logger.info("Token salvo/atualizado: CNPJ={}, Sistema={}, Habilitado={}, Financeiro={}",
                                    cnpj, nomeSistema, settings.getHabilitado(), settings.getStatusFin());
                    }
                } else {
                    logger.warn("Sistema {} não possui módulos configurados.", sistema.getSistema());
                }
            });
        } else {
            logger.warn("Servidor ou sistemas nulos no DTO retornado.");
        }
    }    

    private void carregarTokensDaAPI(String cnpj, File pastaTokens) {
        try {
            TokenEnvioApiContabilidadeDTO envioDto = new TokenEnvioApiContabilidadeDTO(cnpj, PASSWORD_DEFAULT, pastaTokens);
            TokenRetornoApiContabilidadeDTO retornoDto = tokenClient.postToken(envioDto);

            logger.info("Tokens recebidos da API para CNPJ {}.", cnpj);

            // Salvar em disco
            salvarTokensEmDisco(retornoDto, pastaTokens);

            // Salvar no storage
            tokenStorage.save("TokenOriginal", objectMapper.writeValueAsString(retornoDto));
            TokenRetornoApiContabilidadeMinDTO minDto = mapearParaMinDTO(retornoDto);
            tokenStorage.save("TokenReduzido", objectMapper.writeValueAsString(minDto));

            // Salvar no H2
            salvarTokensH2(retornoDto);

        } catch (FeignException e) {
            logger.warn("API indisponível, tentando carregar tokens do storage... [{}]", e.status());
            carregarTokensDoStorage();
        } catch (Exception e) {
            logger.error("Erro ao carregar tokens da API: {}", e.getMessage(), e);
            carregarTokensDoStorage();
        }
    }

    private void carregarTokensDoStorage() {
        try {
            Optional<String> jsonOriginal = tokenStorage.load("TokenOriginal");
            Optional<String> jsonReduzido = tokenStorage.load("TokenReduzido");

            if (jsonOriginal.isPresent() && jsonReduzido.isPresent()) {
                TokenRetornoApiContabilidadeDTO originalDto =
                        objectMapper.readValue(jsonOriginal.get(), TokenRetornoApiContabilidadeDTO.class);
                salvarTokensH2(originalDto);
                logger.info("Tokens carregados do storage com sucesso.");
            } else {
                logger.warn("Nenhum token encontrado no storage.");
            }
        } catch (Exception e) {
            logger.error("Erro ao carregar tokens do storage: {}", e.getMessage(), e);
        }
    }

    private void salvarTokensEmDisco(TokenRetornoApiContabilidadeDTO dto, File pastaTokens) throws IOException {
        pastaTokens.mkdirs();
        String jsonOriginal = objectMapper.writeValueAsString(dto);
        String jsonReduzido = objectMapper.writeValueAsString(mapearParaMinDTO(dto));

        File arqOriginal = new File(pastaTokens, "token_contabilidade_ori.json");
        File arqReduzido = new File(pastaTokens, "token_contabilidade_red.json");

        try (FileWriter fwO = new FileWriter(arqOriginal); FileWriter fwR = new FileWriter(arqReduzido)) {
            fwO.write(jsonOriginal);
            fwR.write(jsonReduzido);
        }

        logger.info("Tokens salvos em disco: {} | {}", arqOriginal.getAbsolutePath(), arqReduzido.getAbsolutePath());
    }
   
    private TokenRetornoApiContabilidadeMinDTO mapearParaMinDTO(TokenRetornoApiContabilidadeDTO dtoCompleto) {
        TokenRetornoApiContabilidadeMinDTO dtoMin = new TokenRetornoApiContabilidadeMinDTO();
        dtoMin.setId(dtoCompleto.getId());
        dtoMin.setCnpj(dtoCompleto.getCnpj());
        dtoMin.setValidade(dtoCompleto.getValidade());
        dtoMin.setAssinatura(dtoCompleto.getAssinatura());

        if (dtoCompleto.getServidor() != null && dtoCompleto.getServidor().getSistemas() != null) {
            dtoCompleto.getServidor().getSistemas().forEach(sistema -> {
                if (sistema.getModulos() != null && !sistema.getModulos().isEmpty()) {
                    var settings = sistema.getModulos().get(0).getSettings();
                    if (settings != null) {
                        TokenRetornoApiContabilidadeMinDTO.SistemaDTO sistemaMin = new TokenRetornoApiContabilidadeMinDTO.SistemaDTO();
                        sistemaMin.setHabilitado(settings.getHabilitado());
                        sistemaMin.setStatusFin(settings.getStatusFin());

                        switch (sistema.getSistema().toUpperCase()) {
                            case "FISCAL" -> dtoMin.setFiscal(sistemaMin);
                            case "CONTABIL" -> dtoMin.setContabil(sistemaMin);
                            case "FOLHA" -> dtoMin.setFolha(sistemaMin);
                        }
                    }
                }
            });
        }
        return dtoMin;
    }
    
    public TokenRetornoApiContabilidadeDTO postTokenContabilidade(TokenEnvioApiContabilidadeDTO body) throws Exception {
        // Chama a API via FeignClient
        TokenRetornoApiContabilidadeDTO retornoDto = tokenClient.postToken(body);

        // Salva em disco
        File pastaTokens = body.getCaminho();
        salvarTokensEmDisco(retornoDto, pastaTokens);

        // Salva no storage
        tokenStorage.save("TokenOriginal", objectMapper.writeValueAsString(retornoDto));
        TokenRetornoApiContabilidadeMinDTO minDto = mapearParaMinDTO(retornoDto);
        tokenStorage.save("TokenReduzido", objectMapper.writeValueAsString(minDto));

        // Salva no H2
        salvarTokensH2(retornoDto);

        return retornoDto;
    }    
}