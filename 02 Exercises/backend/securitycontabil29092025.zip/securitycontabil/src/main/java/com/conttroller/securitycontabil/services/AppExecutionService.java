package com.conttroller.securitycontabil.services;

import java.io.File;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.conttroller.securitycontabil.components.ApplicationContextProvider;
import com.conttroller.securitycontabil.execution.ExecutionControl;

@Service
public class AppExecutionService {

    private static final Logger logger = LoggerFactory.getLogger(AppExecutionService.class);

    private final ExecutionControl executionControl;
    private final TokenExecutorService tokenExecutorService;
    private final AppContextService contextService;
    private final ApplicationContextProvider contextProvider;

    public AppExecutionService(
            ExecutionControl executionControl,
            TokenExecutorService tokenExecutorService,
            AppContextService contextService,
            ApplicationContextProvider contextProvider) {
        this.executionControl = executionControl;
        this.tokenExecutorService = tokenExecutorService;
        this.contextService = contextService;
        this.contextProvider = contextProvider;
    }

    /** Fluxo principal de execução */
    public void executar(String cnpj, String caminhoStr, String tokenFornecido) {
        try {
            File caminho = new File(caminhoStr);
            if (!caminho.exists() && !caminho.mkdirs()) {
                logger.warn("Não foi possível criar o diretório: {}", caminho.getAbsolutePath());
            }

            contextService.setCnpj(cnpj);
            contextService.setCaminho(caminho);

            if (executionControl.isFirstRun()) {
                executarPrimeiraExecucao();
            } else if (tokenFornecido != null && !tokenFornecido.isBlank()) {
                validarERegistrarServico(tokenFornecido);
            } else {
                logger.info("Execução normal: nenhuma ação de registro de serviço requerida.");
            }
        } catch (Exception e) {
            logger.error("Erro durante a execução da aplicação: {}", e.getMessage(), e);
            contextProvider.exitApplication(1);
        }
    }

    /** Primeira execução: gera token e envia por e-mail */
    private void executarPrimeiraExecucao() {
        try {
            logger.info("=== Primeira execução detectada ===");

            // Gera token temporário
            String tokenTemp = tokenExecutorService.gerarToken();
            executionControl.saveToken(tokenTemp);

            // Executa o token real (API/H2) e atualiza tokenGerado
            tokenExecutorService.executarTokenReal();

            // Envia e-mail com token real
            tokenExecutorService.enviarTokenEmail(contextService.getCnpj());

            logger.info("Token enviado com sucesso. A aplicação será finalizada.");
            contextProvider.exitApplication(0);
        } catch (Exception e) {
            logger.error("Erro ao gerar/enviar token real: {}", e.getMessage(), e);
            contextProvider.exitApplication(1);
        }
    }

    /** Valida token fornecido e registra serviço */
    private void validarERegistrarServico(String tokenFornecido) {
        try {
            contextService.setInputToken(tokenFornecido);

            String tokenArmazenado = executionControl.getStoredToken();
            if (!tokenFornecido.equals(tokenArmazenado)) {
                throw new SecurityException("Token inválido. Registro do serviço abortado.");
            }

            logger.info("Token válido. Registrando o serviço no Windows...");
            tokenExecutorService.executarRegistroService();
            logger.info("Serviço registrado com sucesso.");
        } catch (Exception e) {
            logger.error("Falha ao validar token ou registrar serviço: {}", e.getMessage(), e);
            contextProvider.exitApplication(1);
        }
    }
}