package com.conttroller.securitycontabil.services;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailSender {

    private final JavaMailSender mailSender;

    // Construtor sem @Autowired
    public EmailSender(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendEmail(String destinatario, String assunto, String corpo) throws Exception {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, "UTF-8");
        helper.setTo(destinatario);
        helper.setSubject(assunto);
        helper.setText(corpo, true); // HTML permitido
        mailSender.send(message);
    }
}