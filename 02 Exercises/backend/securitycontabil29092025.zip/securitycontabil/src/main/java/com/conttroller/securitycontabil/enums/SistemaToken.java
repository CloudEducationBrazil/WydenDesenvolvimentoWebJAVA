package com.conttroller.securitycontabil.enums;

public enum SistemaToken {
    FISCAL,
    CONTABIL,
    FOLHA;
}