package com.conttroller.securitycontabil.services;

import java.io.File;
import java.security.SecureRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.conttroller.securitycontabil.dto.TokenEnvioApiContabilidadeDTO;
import com.conttroller.securitycontabil.dto.TokenRetornoApiContabilidadeDTO;

@Service
public class TokenExecutorService {

    private static final Logger logger = LoggerFactory.getLogger(TokenExecutorService.class);

    private final TokenService tokenService;
    private final AppContextService contextService;
    private final EmailSender emailSender;

    private String tokenGerado;

    public TokenExecutorService(TokenService tokenService,
                                AppContextService contextService,
                                EmailSender emailSender) {
        this.tokenService = tokenService;
        this.contextService = contextService;
        this.emailSender = emailSender;
    }

    /**
     * Gera um token temporário (para registro inicial).
     */
    public String gerarToken() {
        SecureRandom random = new SecureRandom();
        tokenGerado = String.format("%06d", random.nextInt(1_000_000));
        return tokenGerado;
    }

    /**
     * Executa o token real, pegando do H2/API e atualizando tokenGerado.
     */
    public void executarTokenReal() throws Exception {
        String cnpj = contextService.getCnpj();
        File caminho = contextService.getCaminho();

        if (cnpj == null || cnpj.isBlank()) {
            logger.warn("CNPJ não configurado. Ignorando execução do token real.");
            return;
        }

        if (caminho == null) {
            caminho = new File("C:\\conttrol\\");
            contextService.setCaminho(caminho);
        }

        // Cria DTO para envio
        TokenEnvioApiContabilidadeDTO body = new TokenEnvioApiContabilidadeDTO(cnpj, "", caminho);

        // Chama a API/H2 e atualiza tokenGerado com o token oficial do módulo CONTABIL
        TokenRetornoApiContabilidadeDTO retornoDto = tokenService.postTokenContabilidade(body);

        tokenGerado = retornoDto.getServidor().getSistemas()
                .stream()
                .filter(s -> "CONTABIL".equalsIgnoreCase(s.getSistema()))
                .findFirst()
                .map(s -> s.getModulos() != null && !s.getModulos().isEmpty()
                        ? s.getModulos().get(0).getSettings().getStatusFin()
                        : null)
                .orElse(tokenGerado); // se não encontrar, mantém o temporário
    }

    public void enviarTokenEmail(String cnpj) throws Exception {
        if (tokenGerado == null) {
            logger.warn("Token não gerado. E-mail não será enviado.");
            return;
        }

        String emailDiretor = "helenocardosofilho@gmail.com";
        String assunto = "Token de registro do sistema Conttrol.";
        String corpo = String.format(
                "<p>CNPJ: %s</p><p>Token para autorizar registrar o app Java como serviço do Windows: %s</p>",
                cnpj, tokenGerado
        );

        emailSender.sendEmail(emailDiretor, assunto, corpo);
        logger.info("Token enviado por e-mail para CNPJ={}", cnpj);
    }

    public String getTokenGerado() {
        return this.tokenGerado;
    }
}