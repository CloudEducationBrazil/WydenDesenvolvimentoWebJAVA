package com.conttroller.securitycontabil.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.conttroller.securitycontabil.dto.TokenEnvioApiContabilidadeDTO;
import com.conttroller.securitycontabil.dto.TokenRetornoApiContabilidadeDTO;
import com.conttroller.securitycontabil.services.TokenService;

import java.io.File;

@RestController
@RequestMapping("/api/tokencontabilidade")
public class TokenController {
	// https://conttroller.net/api/d3/token

    @Autowired
    private TokenService tokenService;

    @PostMapping
    public TokenRetornoApiContabilidadeDTO postTokenContabilidade(
            @RequestBody(required = false) TokenEnvioApiContabilidadeDTO body) throws Exception {

        if (body == null) {
            body = new TokenEnvioApiContabilidadeDTO(
                    "00000000000199",
                    "",
                    new File("C:\\conttrol\\")
            );
        }

        return tokenService.postTokenContabilidade(body);
    }
}