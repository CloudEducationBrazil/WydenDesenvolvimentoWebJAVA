package com.conttroller.securitycontabil.execution;

import java.util.prefs.Preferences;

import org.springframework.stereotype.Component;

@Component
public class ExecutionControl {

    private static final String REG_PATH = "Software/lorttnoc/SecurityContabil";
    private static final String TOKEN_KEY = "Token";

    private final Preferences prefs;

    public ExecutionControl() {
        this.prefs = Preferences.userRoot().node(REG_PATH);
    }

    /** Retorna true se for a primeira execução (token ainda não existe no registro) */
    public boolean isFirstRun() {
        return prefs.get(TOKEN_KEY, null) == null;
    }

    /** Grava o token no registro do Windows */
    public void saveToken(String token) {
        prefs.put(TOKEN_KEY, token);
    }

    /** Lê o token armazenado no registro */
    public String getStoredToken() {
        return prefs.get(TOKEN_KEY, null);
    }
}