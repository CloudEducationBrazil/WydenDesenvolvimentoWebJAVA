package com.conttroller.securitycontabil.enums;

public enum StatusToken {
    ATIVO,
    INATIVO,
    EXPIRADO,
    PENDENTE;
}