package com.conttroller.securitycontabil.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.conttroller.securitycontabil.entities.Token;

@Repository
public interface TokenRepository extends JpaRepository<Token, Long> {
	Optional<Token> findByCnpjAndSistema(String cnpj, String sistema);
	
//	@Query("SELECT t FROM Token t WHERE t.sistema = :sistema AND (:cnpj IS NULL OR t.cnpj = :cnpj)")
//	Optional<Token> findBySistemaAndCnpjOptional(@Param("sistema") String sistema, @Param("cnpj") String cnpj);	
}