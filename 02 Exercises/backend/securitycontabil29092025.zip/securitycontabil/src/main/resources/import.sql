INSERT INTO tb_token (cnpj, sistema, habilitado, financeiro) VALUES ('04585532000199', 'CONTABIL', 'A', 'N');
INSERT INTO tb_token (cnpj, sistema, habilitado, financeiro) VALUES ('04585532000199', 'FISCAL', 'A', 'D');
INSERT INTO tb_token (cnpj, sistema, habilitado, financeiro) VALUES ('04585532000199', 'FOLHA', 'I', 'D');