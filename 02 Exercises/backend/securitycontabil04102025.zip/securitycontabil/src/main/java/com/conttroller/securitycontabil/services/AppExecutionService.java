package com.conttroller.securitycontabil.services;

import com.conttroller.securitycontabil.components.AppTerminator;
import com.conttroller.securitycontabil.execution.ExecutionControl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class AppExecutionService {

    private static final Logger logger = LoggerFactory.getLogger(AppExecutionService.class);

    private final ExecutionControl executionControl;
    private final TokenExecutorService tokenExecutorService;
    private final AppContextService contextService;
    private final AppTerminator appTerminator;

    public AppExecutionService(
            ExecutionControl executionControl,
            TokenExecutorService tokenExecutorService,
            AppContextService contextService,
            AppTerminator appTerminator) {
        this.executionControl = executionControl;
        this.tokenExecutorService = tokenExecutorService;
        this.contextService = contextService;
        this.appTerminator = appTerminator;
    }

    public void executar() {
        String tokenFornecido = contextService.getInputToken();
        try {
            if (executionControl.isFirstRun()) {
                executarPrimeiraExecucao();
            } else if (tokenFornecido != null && !tokenFornecido.isBlank()) {
                logger.warn("[APP EXECUTION][SECOND_RUN] Segunda execução via .bat: chamando TokenExecutionService.atualizarTokesParaProducao");

                validarERegistrarServico(tokenFornecido);
            } else {
                logger.info("[APP EXECUTION][NORMAL] Execução normal: nenhuma ação de registro requerida.");
                tokenExecutorService.atualizarJSONParaProducao();
            }
        } catch (Exception e) {
            logger.error("[APP EXECUTION][FAIL] Erro durante a execução: {}", e.getMessage(), e);
            System.out.println("Falha na execução. Consulte os logs para detalhes.");
            appTerminator.exit(1);
        }
    }

    private void executarPrimeiraExecucao() {
        try {
            logger.info("[APP EXECUTION][FIRST_RUN] === Primeira execução ===");

            String tokenTemp = tokenExecutorService.gerarToken();
            executionControl.saveToken(tokenTemp);

            tokenExecutorService.executarTokenReal();
            tokenExecutorService.enviarTokenEmail(contextService.getCnpj(), tokenTemp);

            logger.info("[APP EXECUTION][FIRST_RUN][OK] Token enviado com sucesso. Aplicação encerrada.");
            //System.out.println("Primeira execução concluída. Token enviado via email.");
            appTerminator.exit(0);
        } catch (Exception e) {
            logger.error("[APP EXECUTION][FIRST_RUN][FAIL] Erro na primeira execução: {}", e.getMessage(), e);
            //System.out.println("Falha na primeira execução. Consulte os logs para detalhes.");
            appTerminator.exit(1);
        }
    }

    private void validarERegistrarServico(String tokenFornecido) {
        try {
            contextService.setInputToken(tokenFornecido);

            String tokenArmazenado = executionControl.getStoredToken();
            if (!tokenFornecido.equals(tokenArmazenado)) {
                throw new SecurityException("Token inválido.");
            }

            tokenExecutorService.atualizarJSONParaProducao();
            
            // Gera problemas no serviço TokenService Windows
/*            String serviceName = "TokenService";
            if (!tokenExecutorService.isServiceInstalled(serviceName)) {
                logger.info("[{}] Serviço {} não encontrado. Iniciando instalação...", 
                            java.time.LocalDateTime.now(), serviceName);

                tokenExecutorService.executarRegistroService(tokenArmazenado);
                
                logger.info("[{}] Serviço {} instalado e iniciado com sucesso.", 
                            java.time.LocalDateTime.now(), serviceName);
            } else {
                logger.info("[{}] Serviço {} já instalado. Nenhuma ação necessária.", 
                            java.time.LocalDateTime.now(), serviceName);
            }       
*/
            logger.info("[APP EXECUTION][SECOND_RUN][OK] Serviço registrado com sucesso.");
            //System.out.println("Segunda execução concluída com sucesso. Serviço registrado.");
            
            //appTerminator.exit(0);
        } catch (Exception e) {
            logger.error("[APP EXECUTION][SECOND_RUN][FAIL] Falha ao validar token ou registrar serviço: {}", e.getMessage());
            //System.out.println("Falha na segunda execução. Consulte os logs para detalhes.");
            appTerminator.exit(1);
        }
    }
}