package com.wyden.appusersts.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wyden.appusersts.dto.UserDTO;
import com.wyden.appusersts.entities.User;
import com.wyden.appusersts.services.UserService;

@RestController
@RequestMapping(value = "/users")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@GetMapping
	public List<UserDTO> findAllUsers(){
		return userService.findAllUsers();
	}

	@GetMapping(value = "/{id}")
	public User findByIdUser(@PathVariable Long id){
		return userService.findByIdUser(id);
	}
	
	@PostMapping
	public void saveUser(@RequestBody User user){
		userService.saveUser(user);
	}
	
	@PutMapping(value = "/{id}")
	public void updateUser(@PathVariable Long id, @RequestBody User user){
		userService.updateUser(id, user);
	}
	
	@DeleteMapping(value = "/{id}")
	public void deleteByIdUser(@PathVariable Long id){
		userService.deleteByIdUser(id);
	}
}