package com.wyden.appusersts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppuserstsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppuserstsApplication.class, args);
	}

}
