INSERT INTO tb_user (name, idade) VALUES ('Juju Cardoso');
INSERT INTO tb_user (name, idade) VALUES ('Josy Cardoso');
INSERT INTO tb_user (name, idade) VALUES ('Maria Santos');
INSERT INTO tb_user (name, idade) VALUES ('Paulo Nascimento');
INSERT INTO tb_user (name, idade) VALUES ('Antidio Pinna');
INSERT INTO tb_user (name, idade) VALUES ('Heleno Cardoso');
INSERT INTO tb_user (name, idade) VALUES ('Bebel Cardoso');