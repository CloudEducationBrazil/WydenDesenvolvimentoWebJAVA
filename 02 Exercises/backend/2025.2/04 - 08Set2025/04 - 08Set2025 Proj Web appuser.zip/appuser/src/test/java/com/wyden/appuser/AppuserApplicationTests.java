package com.wyden.appuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
