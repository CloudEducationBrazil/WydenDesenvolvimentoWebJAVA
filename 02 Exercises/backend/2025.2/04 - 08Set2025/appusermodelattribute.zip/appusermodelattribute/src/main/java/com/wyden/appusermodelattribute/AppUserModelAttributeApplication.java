package com.wyden.appusermodelattribute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppUserModelAttributeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppUserModelAttributeApplication.class, args);
	}

}
