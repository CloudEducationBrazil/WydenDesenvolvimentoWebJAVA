package entities;

public class Pessoa {
	public String Cpf;
	public String Nome;
	public int Idade;
	public double Altura;
	
	public String getCpf() {
		return Cpf;
	}
	
	public void setCpf(String cpf) {
		Cpf = cpf;
	}
	
	public String getNome() {
		return Nome;
	}
	
	public void setNome(String nome) {
		Nome = nome;
	}
	
	public int getIdade() {
		return Idade;
	}
	
	public void setIdade(int idade) {
		Idade = idade;
	}
	
	public double getAltura() {
		return Altura;
	}
	
	public void setAltura(double altura) {
		Altura = altura;
	}

	@Override
	public String toString() {
		return "Pessoa [Cpf=" + Cpf + ", Nome=" + Nome + ", Idade=" + Idade + ", Altura=" + Altura + "]";
	}

	public String toStringReduzido() {
		return "Pessoa [Nome=" + Nome + ", Idade=" + Idade + "]";
	}
}
