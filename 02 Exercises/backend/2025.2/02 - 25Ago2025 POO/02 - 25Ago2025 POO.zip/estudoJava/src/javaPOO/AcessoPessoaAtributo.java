package javaPOO;

import entities.Pessoa;

public class AcessoPessoaAtributo {

	public static void main(String[] args) {
		Pessoa p1 = new Pessoa(); // Novo objeto
		
		p1.Cpf = "555555";
 		p1.Nome = "Juju";
		p1.Idade = 20;
		p1.Altura = 1.45;		
		
		Pessoa p2 = new Pessoa() {
			{Cpf = "444444"; Nome = "Maria"; Idade = 74; Altura = 1.57;}
		}; // Novo objeto

		Pessoa p3 = p2; // Acesso por referência p3 = p2
		
		p3.Nome = "Josy";		
		
		System.out.println(String.format("CPF: %s Nome: %s Idade: %d Altura: %.2f",
				                          p1.Cpf, p1.Nome, p1.Idade, p1.Altura));

		System.out.println("CPF: " + p2.Cpf + " Nome: " + p2.Nome + " Idade: "+ p2.Idade);
		
		System.out.println(p1);
		System.out.println(p1.toStringReduzido());
	}
}