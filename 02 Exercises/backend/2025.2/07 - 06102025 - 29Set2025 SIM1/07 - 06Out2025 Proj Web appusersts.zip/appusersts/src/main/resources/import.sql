INSERT INTO tb_user (nome, idade) VALUES ('Juju Cardoso', 20);
INSERT INTO tb_user (nome, idade) VALUES ('Josy Cardoso', 54);
INSERT INTO tb_user (nome, idade) VALUES ('Maria Santos', 72);
INSERT INTO tb_user (nome, idade) VALUES ('Paulo Nascimento', 57);
INSERT INTO tb_user (nome, idade) VALUES ('Antidio Pinna', 55);
INSERT INTO tb_user (nome, idade) VALUES ('Heleno Cardoso', 56);
INSERT INTO tb_user (nome, idade) VALUES ('Bebel Cardoso', 3);