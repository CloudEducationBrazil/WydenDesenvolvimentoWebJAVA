package com.wyden.appusersts.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wyden.appusersts.dto.UserDTO;
import com.wyden.appusersts.entities.User;
import com.wyden.appusersts.repositories.UserRepository;
import com.wyden.appusersts.responses.ResponseMessage;

@Service
public class UserService {
	
	@Autowired
	UserRepository 	userRepository;
	
	@Transactional(readOnly = true)
	public List<UserDTO> findAllUsers(){
		List<User> user   = userRepository.findAll();
		List<UserDTO> dto = user.stream().map(x -> new UserDTO(x)).toList();
				
		return dto;
	}

	@Transactional(readOnly = true)
	public UserDTO findByIdUser(Long id){
		Optional<User> userOptional = userRepository.findById(id);
		
		if ( userOptional.isPresent() ) {
			UserDTO dto = new UserDTO(userOptional.get());
		  return dto;
		}
		else {
			return null;
		}
	}

	@Transactional
	public void saveUser(User user){
		userRepository.save(new User(user));
	}
	
	@Transactional
	public void updateUser(Long id, User user){
		Optional<User> userOptional = userRepository.findById(id);
		
		if ( userOptional.isPresent() ) {
			User result = userOptional.get();
			
			result.setNome(user.getNome());
			result.setIdade(user.getIdade());
			
			userRepository.save(result);
		}
	}
	
	@Transactional
	public ResponseEntity<?> deleteByIdUser(Long id){
		Optional<User>  userOptional = userRepository.findById(id);

		if (!userOptional.isPresent()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseMessage("User não encontrado."));
		}
		
		userRepository.deleteById(id);
		
		return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage("User excluído com sucesso."));

	}
}