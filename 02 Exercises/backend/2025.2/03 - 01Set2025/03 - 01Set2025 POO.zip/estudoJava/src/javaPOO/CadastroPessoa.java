package javaPOO;

import java.util.Scanner;

import entities.PessoaFisica;
import entities.PessoaJuridica;

public class CadastroPessoa {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		PessoaFisica   pesF1 = new PessoaFisica("5555", "Juju");
		PessoaFisica   pesF2 = new PessoaFisica();

		PessoaJuridica pesJ = new PessoaJuridica();
		
		System.out.print("Nome Pessoa Física: ");	pesF2.setNome(ler.next());
		System.out.print("CPF: ");	pesF2.setCpf(ler.next());
		
		System.out.print("Nome Pessoa Jurídica: ");	pesJ.setNome(ler.next());
		System.out.print("CNPJ: ");	pesJ.setCnpj(ler.next());
		
		System.out.println(pesF1);
		System.out.println(pesF2);
		
		System.out.println(pesJ);
		
		ler.close();
	}
}