package javaLogicaProgramacao;

import java.util.ArrayList;

public class VetorDinamico {

	public static void main(String[] args) {
		ArrayList<Integer> vetDinamico = new ArrayList<Integer>();
		
		vetDinamico.add(8);
		vetDinamico.add(21);
		vetDinamico.add(-13);
		
		System.out.println(vetDinamico);
	}
}