package entities;

public class Animal {
    public void fazerSom() {
        System.out.println("O animal faz um som...");
    }
}