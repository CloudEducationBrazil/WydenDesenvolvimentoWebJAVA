package entities;

public class Utils {
	public static String nome;

	public static String teste() {
		return "Oi Estatic";
	}
}