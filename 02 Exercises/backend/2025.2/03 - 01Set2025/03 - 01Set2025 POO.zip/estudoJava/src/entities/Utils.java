package entities;

public class Utils {
	public static String nome;

	public static String imprimeNome() {
		return "executei um método estático.";
	}
}