package com.wyden.appusersts.dto;

import org.springframework.beans.BeanUtils;

import com.wyden.appusersts.entities.User;

public class UserDTO {
	private Long id; 
	
	private String nome;
	private Integer idade;

	public UserDTO() {
	}
	
	public UserDTO(Long id, String nome, Integer idade) {
		this.id = id;
		this.nome = nome;
		this.idade = idade;
	}

	public UserDTO(User user) {
		BeanUtils.copyProperties(user, this);
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getIdade() {
		return idade;
	}

	public void setIdade(Integer idade) {
		this.idade = idade;
	}
}