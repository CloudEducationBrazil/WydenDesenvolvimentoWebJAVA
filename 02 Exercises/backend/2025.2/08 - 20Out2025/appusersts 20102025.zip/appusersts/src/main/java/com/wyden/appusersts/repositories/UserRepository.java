package com.wyden.appusersts.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.wyden.appusersts.entities.User;
import com.wyden.appusersts.projections.UserMinProjection;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	@Query(nativeQuery = true, value = """
			SELECT tb_user.id, tb_user.nome, tb_user.idade
			FROM tb_user
			WHERE tb_user.idade > :idade
			ORDER BY tb_user.idade
				""") 
	List<UserMinProjection> searchAllUsersByIdade(int idade);
}