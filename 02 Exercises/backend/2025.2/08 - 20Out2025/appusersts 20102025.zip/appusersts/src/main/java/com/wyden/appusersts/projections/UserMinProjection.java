package com.wyden.appusersts.projections;

public interface UserMinProjection {
	Long getId();
	String getNome();
	Integer getIdade();
}