/**
 * 
 */
/**
 * 
 */
module tecnicajava {
}