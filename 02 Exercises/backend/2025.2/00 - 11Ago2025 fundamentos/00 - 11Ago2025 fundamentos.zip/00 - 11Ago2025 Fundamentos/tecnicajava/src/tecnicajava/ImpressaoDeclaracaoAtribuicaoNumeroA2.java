package tecnicajava;

public class ImpressaoDeclaracaoAtribuicaoNumeroA2
{
	public static void main(String[] args) {
		int a = 5;

		System.out.print("Número: " + a);
	}
}