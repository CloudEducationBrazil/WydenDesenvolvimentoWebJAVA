package tecnicajava;

public class ImpressaoAtribuicaoNumeroAeB3
{
	public static void main(String[] args) {
		int a = 5;
		int b = 6;

		System.out.print("Número: " + a + " e " + b);
	}
}