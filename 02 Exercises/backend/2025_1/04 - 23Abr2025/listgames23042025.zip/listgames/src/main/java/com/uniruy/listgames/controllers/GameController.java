package com.uniruy.listgames.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uniruy.listgames.entities.Game;
import com.uniruy.listgames.repositories.GameRepository;

@RestController
@RequestMapping(value = "/games")
public class GameController {
	
	@Autowired
	public GameRepository  gameRepository;
	
	@GetMapping
	public List<Game> getAllGame(){
		return gameRepository.findAll();
	}

	@GetMapping(value = "/{id}")
	public Game getGameById(@PathVariable Long id){
		return gameRepository.findById(id).get();
	}
}