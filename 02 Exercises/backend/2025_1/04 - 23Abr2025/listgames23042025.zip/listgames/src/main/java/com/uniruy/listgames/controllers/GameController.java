package com.uniruy.listgames.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uniruy.listgames.entities.Game;
import com.uniruy.listgames.repositories.GameRepository;
import com.uniruy.listgames.responses.ResponseMessage;

@RestController
@RequestMapping(value = "/games")
public class GameController {
	
	// Injeção de dependência de Componente
	@Autowired
	public GameRepository  gameRepository;
	
	// Endpoint Consultar Todos - protocolo HTTP: Método Get
	@GetMapping
	public List<Game> getAllGame(){
		return gameRepository.findAll();
	}

	// Endpoint Consultar por id - protocolo HTTP: Método Get
	@GetMapping(value = "/{id}")
	public Game getGameById(@PathVariable Long id){
		return gameRepository.findById(id).get();
	}
	
	// Endpoint Cadastrar - protocolo HTTP: Método Post
	@PostMapping
	public void postGame(@RequestBody Game body){
		gameRepository.save(body);
	}

	// Endpoint Alterar - protocolo HTTP: Método Put
	@PutMapping(value = "/{id}")
	public ResponseEntity<?> putGame(@PathVariable Long id, @RequestBody Game body){
		Optional<Game> gameOptional = gameRepository.findById(id);
		
		if ( !gameOptional.isPresent() )
		{  ResponseMessage responseMessage = new ResponseMessage("Game não encontrado ...");
		   //return ResponseEntity.notFound().build();
		   return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMessage);
		}   

		Game game = gameOptional.get();
		
		game.setTitle(body.getTitle());
		game.setImgUrl(body.getImgUrl());
		game.setPlatforms(body.getPlatforms());
		game.setScore(body.getScore());
		game.setYear(body.getYear());
		game.setGenre(body.getGenre());
		game.setShortDescription(body.getShortDescription());
		game.setLongDescription(body.getLongDescription());
		
		gameRepository.save(game);
		
		ResponseMessage responseMessage = new ResponseMessage("Game atualizado com sucesso ...");
		   
//		return ResponseEntity.ok().build();
		return ResponseEntity.status(HttpStatus.OK).body(responseMessage);
	}

	// Endpoint Excluir - protocolo HTTP: Método Delete
	@DeleteMapping(value = "/{id}")
	public ResponseEntity<?> deleteGame(@PathVariable Long id){
		Optional<Game> gameOptional = gameRepository.findById(id);

		if ( !gameOptional.isPresent() )
		{  ResponseMessage responseMessage = new ResponseMessage("Game não encontrado ...");
		   //return ResponseEntity.notFound().build();
		   return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseMessage);
		}
		
		gameRepository.deleteById(id);
		
		ResponseMessage responseMessage = new ResponseMessage("Game excluído com sucesso ...");
		
//		return ResponseEntity.ok().build();
		return ResponseEntity.status(HttpStatus.OK).body(responseMessage);
	}
}