package com.uniruy.listgames.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uniruy.listgames.entities.Belonging;
import com.uniruy.listgames.entities.BelongingPK;

@Repository
public interface BelongingRepository extends JpaRepository<Belonging, BelongingPK>{
}
