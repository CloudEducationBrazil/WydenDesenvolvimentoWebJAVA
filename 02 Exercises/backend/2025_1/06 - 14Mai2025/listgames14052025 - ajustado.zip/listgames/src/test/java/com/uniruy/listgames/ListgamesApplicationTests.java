package com.uniruy.listgames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListgamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
