package com.uniruy.listgames.projections;

public interface BelongingProjection {
	Long getGameId();
	Long getGameListId();
}
