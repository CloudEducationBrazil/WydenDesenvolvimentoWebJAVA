package com.uniruy.listgames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListgamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ListgamesApplication.class, args);
	}
}